# Kaynakça ve Lisanslar (CREDITS)

Bu belge, Frostbound'da kullanılan tüm üçüncü taraf bileşenleri ve görsel/ses varlıklarının kaynaklarını listeler.

> ⚠️ **GitHub'a yüklemeden önce:** Aşağıda **`[DOLDURUN]`** ile işaretli alanlar, proje dosyalarından doğrulanamayan bilgilerdir (görsellerin kim tarafından / hangi araçla üretildiği ve lisansı). Bu bilgiyi yalnızca siz bilebilirsiniz; yanlış atıf yapmamak için boş bırakıldı.

---

## 1. Oyun motoru

| Bileşen | Sürüm | Lisans | Bağlantı |
|---|---|---|---|
| Godot Engine | 4.3+ | MIT | https://godotengine.org |

Telif: © 2014-present Godot Engine contributors, © 2007-2014 Juan Linietsky, Ariel Manzur.

Derlenen `Frostbound.exe`, Godot çalışma zamanını içerir. Godot'un kendi içinde barındırdığı üçüncü taraf kütüphanelerin (FreeType, HarfBuzz, libpng, zlib, mbedTLS vb.) lisans metinleri Godot editöründe **Help → About Godot → Third-party Licenses** altında ve https://github.com/godotengine/godot/blob/master/COPYRIGHT.txt adresinde bulunur. Binary dağıtımında bu lisans bildirimlerinin korunması gerekir; bu belge ve repo bu amaca hizmet eder.

## 2. Yazı tipi

Projede **özel font dosyası yoktur**. Metinler Godot'un yerleşik varsayılan yazı tipiyle (`ThemeDB.fallback_font`) çizilir. Godot'un gömülü varsayılan fontu **Open Sans** ailesidir (Apache License 2.0, © Google / Steve Matteson), motorla birlikte gelir.

## 3. Ses

Projede **hiç ses dosyası (.wav/.ogg/.mp3) yoktur.** Tüm ses efektleri (rüzgar, kalp atışı, siren, konuşma "blip"leri, kapı, kıvılcım, deprem vb.) çalışma anında `scripts/sfx.gd` ile **kodla sentezlenir**. Üçüncü taraf ses kaynağı kullanılmamıştır.

## 4. Kod

| Dosya grubu | Yazar | Lisans |
|---|---|---|
| `scripts/*.gd`, `shaders/*.gdshader`, `scenes/*.tscn` | [DOLDURUN: ad / kullanıcı adı] (Claude / Anthropic yardımıyla hazırlanmıştır) | MIT (bkz. `LICENSE`) |

Üçüncü taraf kütüphane, eklenti (addon) veya kod parçası kullanılmamıştır. Efektler (kar, sis, kırağı, TV statiği, post-process) projeye özgü shader ve `_draw()` kodudur.

## 5. Görsel varlıklar (`assets/`)

Projede bu görsellerin kaynağına dair bir atıf/metaveri bulunmamaktadır (PNG/JPG içinde yazar bilgisi yok). Projenin `README`'sine göre durum şöyledir:

### 5.1 Harita
| Dosya | Boyut |
|---|---|
| `assets/map.jpg` | 2576x1093 |

- Kullanım: ev planı, ana oyun sahnesi ve giriş ekranı arka planı. Çarpışma/eşya/kapı koordinatları bu görsele göre ölçülmüştür (`scripts/level_data.gd`).
- Kaynak / yazar: **[DOLDURUN]**
- Üretim yöntemi (elle çizim / yapay zekâ / stok / satın alma): **[DOLDURUN]**
- Lisans / kullanım izni: **[DOLDURUN]**

### 5.2 Oyuncu karakteri ("eski asker") sprite'ları
Karakter kareleri, sağlanan sprite sheet'lerden kare kare kesilip 72x80 tuvale ayak hizası korunarak yerleştirilmiştir (yürüme, tırmanma, tökezleme, çömelme).

| Dosya | Boyut |
|---|---|
| `assets/sprites/back_idle.png` | 72x80 |
| `assets/sprites/back_walk1.png` | 72x80 |
| `assets/sprites/back_walk2.png` | 72x80 |
| `assets/sprites/climb1.png` | 72x80 |
| `assets/sprites/climb2.png` | 72x80 |
| `assets/sprites/crouch1.png` | 72x80 |
| `assets/sprites/crouch2.png` | 72x80 |
| `assets/sprites/crouch3.png` | 72x80 |
| `assets/sprites/crouch4.png` | 72x80 |
| `assets/sprites/front_idle.png` | 72x80 |
| `assets/sprites/front_walk1.png` | 72x80 |
| `assets/sprites/front_walk2.png` | 72x80 |
| `assets/sprites/side_l.png` | 72x80 |
| `assets/sprites/side_l_a.png` | 72x80 |
| `assets/sprites/side_l_b.png` | 72x80 |
| `assets/sprites/side_r.png` | 72x80 |
| `assets/sprites/side_r_a.png` | 72x80 |
| `assets/sprites/side_r_b.png` | 72x80 |
| `assets/sprites/stumble.png` | 72x80 |

- Orijinal sprite sheet'in kaynağı / yazarı: **[DOLDURUN]**
- Üretim yöntemi: **[DOLDURUN]**
- Lisans / kullanım izni: **[DOLDURUN]**
- Değişiklikler: sheet'lerden kesme, tuval hizalama, `side_l*` karelerinin `side_r*` karelerinin yatay çevrilmesiyle elde edilmesi (README'ye göre sol yön = yatay çevrilmiş).

### 5.3 Kurtarılan karakterler (NPC)
Leyla, Barbaros, Yusuf, Selahattin, Zeynep (her biri için 3 kare: `_0`, `_1`, `_2`).

| Dosya | Boyut |
|---|---|
| `assets/npc/barbaros_0.png` | 72x100 |
| `assets/npc/barbaros_1.png` | 72x100 |
| `assets/npc/barbaros_2.png` | 72x100 |
| `assets/npc/leyla_0.png` | 72x100 |
| `assets/npc/leyla_1.png` | 72x100 |
| `assets/npc/leyla_2.png` | 72x100 |
| `assets/npc/selahattin_0.png` | 72x100 |
| `assets/npc/selahattin_1.png` | 72x100 |
| `assets/npc/selahattin_2.png` | 72x100 |
| `assets/npc/yusuf_0.png` | 72x100 |
| `assets/npc/yusuf_1.png` | 72x100 |
| `assets/npc/yusuf_2.png` | 72x100 |
| `assets/npc/zeynep_0.png` | 72x100 |
| `assets/npc/zeynep_1.png` | 72x100 |
| `assets/npc/zeynep_2.png` | 72x100 |

- Kaynak / yazar / yöntem: **[DOLDURUN]**
- Lisans / kullanım izni: **[DOLDURUN]**
- Karakter adları ve hikâyeleri kurgusaldır; gerçek kişilerle ilgisi yoktur.

### 5.4 Eşya ikonları
Battaniye, fener, konserve, ilk yardım çantası, bıçak, kütük, kibrit, su, pil, el feneri, mont, radyo.

| Dosya | Boyut |
|---|---|
| `assets/items/battery.png` | 54x54 |
| `assets/items/blanket.png` | 54x54 |
| `assets/items/can.png` | 54x54 |
| `assets/items/coat.png` | 54x54 |
| `assets/items/firstaid.png` | 54x54 |
| `assets/items/flashlight.png` | 54x54 |
| `assets/items/knife.png` | 54x54 |
| `assets/items/lantern.png` | 54x54 |
| `assets/items/log.png` | 54x54 |
| `assets/items/matches.png` | 54x54 |
| `assets/items/radio.png` | 54x54 |
| `assets/items/water.png` | 54x54 |

- Kaynak / yazar / yöntem: **[DOLDURUN]**
- Lisans / kullanım izni: **[DOLDURUN]**

### 5.5 Sığınak girişi
| Dosya | Boyut |
|---|---|
| `assets/hatch_closed.png` | 96x64 |
| `assets/hatch_open.png` | 96x64 |

- Proje README'sine göre "üretilen sığınak giriş sanatı"dır. Üretim yöntemi / yazar: **[DOLDURUN]**
- Lisans / kullanım izni: **[DOLDURUN]**

## 6. Kullanılan araçlar

- Godot Engine 4.3 (oyun motoru ve editör)
- Kod, görsel işleme (sprite kesme/hizalama) ve dokümantasyon yardımı: Claude (Anthropic)
- Diğer görsel/yapay zekâ araçları: **[DOLDURUN]**

## 7. Lisans özeti

| Bölüm | Lisans |
|---|---|
| Kaynak kod | MIT |
| Godot Engine ve gömülü bileşenler | MIT ve ilgili üçüncü taraf lisansları (yukarıda) |
| Görseller (`assets/`) | **[DOLDURUN]** – yukarıdaki kaynak bilgisine göre belirleyin. Kaynağı ve izni net olmayan görselleri herkese açık repoda "tüm hakları saklıdır" olarak bırakmak veya değiştirmek en güvenli yoldur. |

Önerilen varlık lisansı (görseller size aitse): **CC BY 4.0** veya **CC BY-NC 4.0**; hazır/üçüncü taraf görseller varsa onların kendi lisans şartları geçerlidir.
