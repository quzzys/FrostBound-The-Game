@echo off
chcp 65001 >nul
REM Frostbound - Windows EXE derleme betigi
REM Gereken: Godot 4.3+ (standart surum) + Export Templates (Editor > Manage Export Templates)
REM Kullanim:  tools\build_windows.bat  [Godot.exe yolu]

setlocal
cd /d "%~dp0\.."

set GODOT=%~1
if "%GODOT%"=="" set GODOT=godot

where "%GODOT%" >nul 2>nul
if errorlevel 1 (
  echo [HATA] Godot bulunamadi. Godot.exe yolunu parametre verin:
  echo        tools\build_windows.bat "C:\Godot\Godot_v4.3-stable_win64.exe"
  exit /b 1
)

if not exist build\windows mkdir build\windows

echo [1/2] Proje iceri aktariliyor...
"%GODOT%" --headless --import

echo [2/2] EXE export ediliyor...
"%GODOT%" --headless --export-release "Windows Desktop" build\windows\Frostbound.exe
if errorlevel 1 (
  echo [HATA] Export basarisiz. Export Templates kurulu mu?
  exit /b 1
)

echo.
echo Hazir: build\windows\Frostbound.exe
endlocal
