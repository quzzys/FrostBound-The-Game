#!/usr/bin/env bash
# Frostbound - Linux/macOS uzerinden Windows EXE derleme
# Gereken: Godot 4.3+ ve Windows export template'leri
# Kullanim: tools/build_windows.sh [godot_komutu]
set -euo pipefail
cd "$(dirname "$0")/.."
GODOT="${1:-godot}"
mkdir -p build/windows
"$GODOT" --headless --import || true
"$GODOT" --headless --export-release "Windows Desktop" build/windows/Frostbound.exe
echo "Hazir: build/windows/Frostbound.exe"
