# EXE Derleme Rehberi

Çıktı: tek dosyalı `Frostbound.exe` (PCK içine gömülü, Windows x86_64).

## Yöntem 1 – GitHub Actions (önerilen, kurulum gerektirmez)

Repo'yu GitHub'a yükledikten sonra:

- `main` dalına her push'ta **Actions → Windows EXE derle** çalışır; exe, çalıştırma sayfasındaki **Artifacts → Frostbound-windows** altında durur.
- Sürüm yayınlamak için etiket at:
  ```bash
  git tag v1.0.0
  git push origin v1.0.0
  ```
  Bu, **Releases** sayfasına `Frostbound-windows.zip` dosyasını otomatik ekler.

> Not: Repo ayarlarında *Settings → Actions → General → Workflow permissions* altında **Read and write permissions** açık olmalı (release adımı için).

## Yöntem 2 – Windows'ta yerel derleme

1. [Godot 4.3+](https://godotengine.org/download) standart sürümünü indir.
2. Godot'u aç → **Editor → Manage Export Templates → Download and Install**.
3. Komut satırından:
   ```bat
   tools\build_windows.bat "C:\Godot\Godot_v4.3-stable_win64.exe"
   ```
   Çıktı: `build\windows\Frostbound.exe`

Alternatif (arayüzden): **Project → Export → Windows Desktop → Export Project**.

## Yöntem 3 – Linux/macOS'ta Windows exe üretme

```bash
tools/build_windows.sh godot
```
(Godot ve export template'leri kurulu olmalı.)

## Sık karşılaşılan sorunlar

| Sorun | Çözüm |
|---|---|
| `No export template found` | Export Templates, Godot sürümüyle birebir aynı olmalı (4.3 ↔ 4.3). |
| exe'de Godot ikonu görünüyor | `export_presets.cfg` içinde `application/modify_resources=true` yapıp Windows'ta derleyin (CI'da rcedit gerekir). |
| SmartScreen uyarısı | Exe kod imzalı değil; normaldir. |
| Release adımı 403 veriyor | Workflow permissions'ı "Read and write" yap. |
