# ❄️ FROSTBOUND – 2 Dakika

Godot 4.3 ile yapılmış, 2D top-down hayatta kalma oyunu.
TV'de *"Dünya yörüngesinden saptı, 2 dakika içinde her şey donacak"* haberi verilir ve geri sayım başlar.

## Oynanış

1. **Eşyalar:** Evdeki rastgele 10 eşyayı topla (ana kapı donmuş, açılmaz).
2. **Kurtarma:** Dışarıdan yardım çığlıkları gelir, ana kapı açılır. Leyla, Barbaros, Yusuf, Selahattin ve Zeynep'i bul; her biriyle kısa bir konuşma yapılır, kurtarılan seni takip eder.
3. **Sığınak:** Hepsi seninle olunca sağ üst odadaki sığınak girişi açılır. Hepiniz atlayınca oyun biter.

## Kontroller

| Tuş | İşlev |
|---|---|
| `W A S D` / Ok tuşları | Hareket |
| `Shift` | Koş |
| `Boşluk` / `Enter` | Haberi atla / diyaloğu ilerlet |
| `R` | Yeniden başla |
| `Esc` | Menüye dön / çık |

## İndir ve oyna (Windows)

[Releases](../../releases) sayfasından `Frostbound-windows.zip` dosyasını indir, çıkar ve `Frostbound.exe` dosyasını çalıştır. Kurulum gerekmez.

> Windows SmartScreen "bilinmeyen yayıncı" uyarısı verebilir (exe imzalı değil). "Ek bilgi → Yine de çalıştır" ile açabilirsin.

## Kaynaktan çalıştırma

1. [Godot 4.3+](https://godotengine.org/download) (standart sürüm) indir.
2. Godot'ta `project.godot` dosyasını içe aktar ve **F5**'e bas.

EXE üretmek için: [docs/BUILD.md](docs/BUILD.md)

## Proje yapısı

```
frostbound/
├── assets/
│   ├── map.jpg            # ev haritası (2576x1093)
│   ├── hatch_*.png        # sığınak girişi (açık/kapalı)
│   ├── sprites/           # oyuncu animasyon kareleri
│   ├── npc/               # kurtarılan karakterler
│   └── items/             # toplanabilir eşya ikonları
├── scenes/                # Title.tscn, Main.tscn
├── scripts/
│   ├── main.gd            # oyun akışı
│   ├── level_data.gd      # harita verisi: çarpışma, eşya noktaları, kapılar
│   ├── dialogues.gd       # konuşma metinleri (kolayca düzenlenir)
│   ├── player.gd, survivor.gd, door.gd, hatch.gd, item_pickup.gd
│   ├── title.gd, dialogue_box.gd, tv_screen.gd, edge_markers.gd
│   └── sfx.gd, ambience.gd, weather.gd, fx.gd   # ses ve efektler
├── shaders/               # post.gdshader, tv_static.gdshader, tv_screen_mini.gdshader
├── tools/                 # yerel derleme betikleri
├── docs/BUILD.md          # EXE derleme rehberi
├── .github/workflows/     # otomatik EXE derleme (GitHub Actions)
├── export_presets.cfg     # Windows export ayarı
├── CREDITS.md             # kaynakça ve lisanslar
└── LICENSE
```

## Teknik notlar

- Renderer: GL Compatibility (eski ekran kartlarında da çalışır), 1280x720, `canvas_items` esnetme.
- **Tüm sesler kodla üretilir** (`sfx.gd`), ses dosyası yoktur.
- Efektler: kar fırtınası, rüzgar, kırağı, titreyen ışıklar, kıvılcım, duman, deprem tozu, kalp atışı ve siren, yönlü ses, ekran kenarı okları.
- Harita koordinatları (çarpışma, eşya, TV, sığınak) `level_data.gd` içindedir; harita değişirse buradan yeniden ölçülmelidir.

## Lisans

Kaynak kod MIT lisanslıdır (bkz. [LICENSE](LICENSE)). Görseller ve üçüncü taraf bileşenler için [CREDITS.md](CREDITS.md).
