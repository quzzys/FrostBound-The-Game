class_name Player
extends Node2D
# Ana karakter (yesil montlu). Sprite sheet'ten kesilen kareler assets/sprites/ icinde:
#   on yurume (2 kare, geri.png) + on bekleme, arka yurume (2 kare, ileri.png) + arka bekleme,
#   yan yurume (sagsol3.png; sol = yatay cevrilmis kopya) + yan bekleme,
#   tirmanma (2 kare: siginaga inis), comelme (4 kare: donma), tokezleme (deprem).
# Hareket: WASD / ok tuslari, Shift = kos.

const WALK_SPEED := 250.0
const RUN_SPEED := 390.0

var controllable: bool = false
var gate_closed: bool = true
var facing: Vector2 = Vector2.UP
var moving: bool = false
var running: bool = false
var anim_t: float = 0.0
var step_timer: float = 0.0
var print_timer: float = 0.0
var print_flip: bool = false
var shiver: float = 0.0
var pop_k: float = 0.0
var crouch_mode: bool = false
var climb_mode: bool = false
var crouch_t: float = 0.0
var stumble_t: float = 0.0
var outside: bool = false
var body: Node2D
var sprite: Sprite2D
var breath: CPUParticles2D
var prints_parent: Node = null

var tex: Dictionary = {}


func _ready() -> void:
	for n in ["front_idle", "front_walk1", "front_walk2", "back_idle", "back_walk1", "back_walk2", "side_r", "side_l",
			"side_r_a", "side_r_b", "side_l_a", "side_l_b",
			"climb1", "climb2", "crouch1", "crouch2", "crouch3", "crouch4", "stumble"]:
		tex[n] = load("res://assets/sprites/%s.png" % n)
	body = Node2D.new()
	add_child(body)
	sprite = Sprite2D.new()
	sprite.texture = tex["back_idle"]
	sprite.offset = Vector2(0, -38)
	body.add_child(sprite)

	# nefes buhari
	breath = CPUParticles2D.new()
	breath.amount = 10
	breath.lifetime = 1.1
	breath.direction = Vector2(0, -1)
	breath.spread = 35.0
	breath.gravity = Vector2(0, -22)
	breath.initial_velocity_min = 8.0
	breath.initial_velocity_max = 22.0
	breath.scale_amount_min = 0.05
	breath.scale_amount_max = 0.14
	breath.texture = Fx.glow_tex()
	var ramp := Gradient.new()
	ramp.set_color(0, Color(0.9, 0.96, 1.0, 0.0))
	ramp.add_point(0.25, Color(0.9, 0.96, 1.0, 0.55))
	ramp.set_color(ramp.get_point_count() - 1, Color(0.9, 0.96, 1.0, 0.0))
	breath.color_ramp = ramp
	breath.position = Vector2(0, -58)
	breath.emitting = false
	add_child(breath)
	queue_redraw()


func _draw() -> void:
	draw_set_transform(Vector2(0, -2), 0.0, Vector2(1.0, 0.38))
	draw_circle(Vector2.ZERO, 22.0, Color(0, 0, 0, 0.38))
	draw_set_transform(Vector2.ZERO, 0.0, Vector2.ONE)


func _process(delta: float) -> void:
	if controllable:
		_move(delta)
	else:
		moving = false
	outside = LevelData.is_outside(position)
	_animate(delta)


func _move(delta: float) -> void:
	var d := Vector2.ZERO
	if Input.is_key_pressed(KEY_A) or Input.is_key_pressed(KEY_LEFT):
		d.x -= 1.0
	if Input.is_key_pressed(KEY_D) or Input.is_key_pressed(KEY_RIGHT):
		d.x += 1.0
	if Input.is_key_pressed(KEY_W) or Input.is_key_pressed(KEY_UP):
		d.y -= 1.0
	if Input.is_key_pressed(KEY_S) or Input.is_key_pressed(KEY_DOWN):
		d.y += 1.0
	moving = d != Vector2.ZERO
	running = Input.is_key_pressed(KEY_SHIFT)
	if not moving:
		return
	d = d.normalized()
	if absf(d.x) > absf(d.y) + 0.01:
		facing = Vector2(signf(d.x), 0.0)
	else:
		facing = Vector2(0.0, signf(d.y))
	var speed := RUN_SPEED if running else WALK_SPEED
	if stumble_t > 0.0:
		speed *= 0.35
	var step := d * speed * delta
	# eksenleri ayri dene -> duvarlara surtunerek kayar
	var before := position
	var nx := position + Vector2(step.x, 0.0)
	if LevelData.is_free(LevelData.feet_rect(nx), gate_closed):
		position = nx
	var ny := position + Vector2(0.0, step.y)
	if LevelData.is_free(LevelData.feet_rect(ny), gate_closed):
		position = ny
	if before.distance_to(position) < 0.01:
		moving = false     # duvara dayandi
		return
	var is_out := LevelData.is_outside(position)
	# ayak sesi + kar izi / toz
	step_timer -= delta
	if step_timer <= 0.0:
		step_timer = 0.2 if running else 0.3
		if is_out:
			Sfx.play("snowstep", -9.0, randf_range(0.85, 1.15))
		else:
			Sfx.play("step", -14.0, randf_range(0.85, 1.15))
	if is_out and prints_parent != null:
		print_timer -= delta
		if print_timer <= 0.0:
			print_timer = 0.17 if running else 0.26
			print_flip = not print_flip
			Fx.footprint(prints_parent, position, print_flip)
			if running:
				Fx.puff(prints_parent, position + Vector2(0, -2), 5, 34.0, 0.16)


func _animate(delta: float) -> void:
	anim_t += delta * (1.4 if running else 1.0)
	stumble_t = maxf(0.0, stumble_t - delta)
	if crouch_mode:
		crouch_t += delta * 6.0
		var idx := int(crouch_t) % 4 + 1
		sprite.texture = tex["crouch%d" % idx]
		sprite.flip_h = false
		body.position = Vector2(randf_range(-1.0, 1.0), randf_range(-0.5, 0.5)) * 2.5
		body.rotation = 0.0
		body.scale = Vector2.ONE
		return
	if climb_mode:
		crouch_t += delta * 7.0
		sprite.texture = tex["climb1"] if int(crouch_t) % 2 == 0 else tex["climb2"]
		sprite.flip_h = false
		body.rotation = 0.0
		return
	if stumble_t > 0.0:
		sprite.texture = tex["stumble"]
		sprite.flip_h = facing.x < 0.0
		body.position = Vector2(randf_range(-1.5, 1.5), 0.0)
		body.rotation = 0.0
		return

	# 4 fazli yuruyus dongusu: adim1 - durus - adim2 - durus
	var phase4 := int(anim_t * 8.0) % 4
	var step_bob := 0.0
	if moving:
		step_bob = absf(sin(anim_t * 8.0 * 3.14159 * 0.5)) * 3.0
	sprite.flip_h = false
	if facing.y > 0.5:
		if moving:
			if phase4 == 0:
				sprite.texture = tex["front_walk1"]
			elif phase4 == 2:
				sprite.texture = tex["front_walk2"]
			else:
				sprite.texture = tex["front_idle"]
		else:
			sprite.texture = tex["front_idle"]
	elif facing.y < -0.5:
		if moving:
			if phase4 == 0:
				sprite.texture = tex["back_walk1"]
			elif phase4 == 2:
				sprite.texture = tex["back_walk2"]
			else:
				sprite.texture = tex["back_idle"]
		else:
			sprite.texture = tex["back_idle"]
	else:
		var side := "side_r" if facing.x > 0.0 else "side_l"
		if moving:
			# verilen adim kareleri: 1 - 2 - 1 - 2
			sprite.texture = tex[side + ("_a" if int(anim_t * 7.0) % 2 == 0 else "_b")]
		else:
			sprite.texture = tex[side]

	if moving:
		body.rotation = sin(anim_t * 14.0) * 0.045
		body.position = Vector2(0, -step_bob)
		body.scale = Vector2(1.0 + sin(anim_t * 28.0) * 0.02, 1.0 - sin(anim_t * 28.0) * 0.02)
	else:
		body.rotation = lerpf(body.rotation, 0.0, 0.3)
		body.position = Vector2.ZERO
		body.scale = Vector2(1.0, 1.0 + sin(anim_t * 2.6) * 0.014)
	body.scale *= Vector2(1.0 + 0.18 * pop_k, 1.0 - 0.16 * pop_k)
	if shiver > 0.0:
		body.position += Vector2(randf_range(-1.0, 1.0), randf_range(-0.6, 0.6)) * shiver


func pop() -> void:
	pop_k = 1.0
	var tw := create_tween()
	tw.tween_property(self, "pop_k", 0.0, 0.28).set_trans(Tween.TRANS_QUAD).set_ease(Tween.EASE_OUT)


func stumble(dur: float = 0.4) -> void:
	if controllable and not crouch_mode and not climb_mode:
		stumble_t = dur


func set_cold(c: float) -> void:
	# c: 0..1 -> nefes buhari ve titreme (disarida daha cok)
	var k := c + (0.3 if outside else 0.0)
	breath.emitting = k > 0.15
	var amt := 6 + int(clampf(k, 0.0, 1.0) * 12.0)
	if amt != breath.amount:
		breath.amount = amt
	shiver = clampf((k - 0.55) * 2.2, 0.0, 1.4)
