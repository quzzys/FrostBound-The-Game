extends Node2D
# FROSTBOUND - 2 Dakika
# Televizyon haberi: dunya yorungesinden saptı, 2 dakika icinde her sey donacak.
# ASAMA 1: evdeki 10 hayatta kalma esyasini topla (ana kapi kilitli).
# ASAMA 2: disaridan yardim cigliklari gelir; kapi acilir, 5 kazazedeyi bul, kisa konus, kurtar.
# ASAMA 3: hepsi seninle -> sag ustteki odadaki SIGINAK girisine atla.

enum State { INTRO, PLAY, DIALOGUE, ENTERING, WIN, LOSE }

const TOTAL_TIME := 120.0
const ITEM_COUNT := 10
const SURVIVOR_COUNT := 5
const VIEW := Vector2(1280, 720)
const DIALOGUE_TIME_SCALE := 0.35

const ITEM_DEFS := [
	{"id": "coat", "name": "Kalın Mont"},
	{"id": "can", "name": "Konserve"},
	{"id": "water", "name": "Su Şişesi"},
	{"id": "firstaid", "name": "İlk Yardım Çantası"},
	{"id": "flashlight", "name": "El Feneri"},
	{"id": "battery", "name": "Pil"},
	{"id": "blanket", "name": "Battaniye"},
	{"id": "matches", "name": "Kibrit"},
	{"id": "radio", "name": "Telsiz"},
	{"id": "knife", "name": "Av Bıçağı"},
	{"id": "log", "name": "Odun"},
	{"id": "lantern", "name": "Gaz Lambası"},
]

var state: int = State.INTRO
var phase: int = 1
var time_left: float = TOTAL_TIME
var collected: int = 0
var rescued_n: int = 0
var skip_intro: bool = false

# dunya
var world: Node2D
var world_mod: CanvasModulate
var player: Player
var camera: Camera2D
var hatch: Hatch
var ambience: Ambience
var items_root: Node2D
var prints_root: Node2D
var survivors_root: Node2D
var items: Array = []
var chosen: Array = []
var survivors: Array = []
var followers: Array = []
var trail: Array = []
var arrow: Polygon2D
var tv_mat: ShaderMaterial
var tv_rect: ColorRect
var door_light: Sprite2D
var doors: Array = []
var front_door: Door
var door_snow: CPUParticles2D
var door_open_k: float = 0.0
var current_sv: Survivor = null

# katmanlar
var tv_layer: CanvasLayer
var tv_screen: TVScreen
var tv_static: ColorRect
var tv_static_mat: ShaderMaterial
var weather: Weather
var post_layer: CanvasLayer
var post_mat: ShaderMaterial
var hud: CanvasLayer
var fade_rect: ColorRect
var dialogue: DialogueBox
var edge: EdgeMarkers

# hud
var timer_label: Label
var bar_fill: ColorRect
var temp_label: Label
var obj_label: Label
var inv_panel: Panel
var inv_title: Label
var slots: Array = []
var rescue_slots: Array = []
var rescue_title: Label
var msg_label: Label
var big_label: Label
var sub_label: Label
var hint_label: Label
var hud_root: Control

# efektler (post shader parametreleri)
var fx_glitch: float = 0.0
var fx_cold: float = 0.0
var fx_frost: float = 0.0
var fx_flash: float = 0.0
var fx_alarm: float = 0.0
var fx_tv: float = 0.0
var frost_boost: float = 0.0
var tv_amount: float = 0.35
var tv_alert: float = 0.0

# kamera
var cam_off: Vector2 = Vector2.ZERO
var cam_zoom_extra: float = 1.0
var shake_base: float = 0.0
var shake_kick: float = 0.0

# sayaclar
var last_sec: int = 999
var beat_timer: float = 0.0
var rumble_timer: float = 11.0
var groan_timer: float = 18.0
var warned: Dictionary = {}
var denied_cd: float = 0.0
var intro_tweens: Array = []
var last_typed: int = 0
var ending: bool = false


func _ready() -> void:
	randomize()
	_build_world()
	_build_tv_layer()
	_build_weather()
	_build_post()
	_build_hud()
	_build_fade()
	_run_intro()


# ====================================================================== KURULUM
func _build_world() -> void:
	world_mod = CanvasModulate.new()
	add_child(world_mod)
	world = Node2D.new()
	add_child(world)

	var map := Sprite2D.new()
	map.texture = load("res://assets/map.jpg")
	map.centered = false
	world.add_child(map)

	ambience = Ambience.new()
	world.add_child(ambience)

	# evdeki televizyonun ekrani (parazit shader'i)
	tv_rect = ColorRect.new()
	tv_rect.position = LevelData.TV_RECT.position
	tv_rect.size = LevelData.TV_RECT.size
	tv_mat = ShaderMaterial.new()
	tv_mat.shader = load("res://shaders/tv_screen_mini.gdshader")
	tv_mat.set_shader_parameter("rect_size", LevelData.TV_RECT.size)
	tv_rect.material = tv_mat
	world.add_child(tv_rect)

	# SIGINAK girisi (sag ust oda)
	hatch = Hatch.new()
	hatch.position = LevelData.HATCH_POS
	world.add_child(hatch)

	_build_door_fx()

	items_root = Node2D.new()
	world.add_child(items_root)
	_spawn_items()

	prints_root = Node2D.new()
	world.add_child(prints_root)

	survivors_root = Node2D.new()
	world.add_child(survivors_root)
	_spawn_survivors()

	player = Player.new()
	player.position = LevelData.SPAWN_POS
	player.prints_parent = prints_root
	world.add_child(player)

	arrow = Polygon2D.new()
	arrow.polygon = PackedVector2Array([Vector2(18, 0), Vector2(-8, -10), Vector2(-3, 0), Vector2(-8, 10)])
	arrow.color = Color(1.0, 0.9, 0.3, 0.9)
	arrow.visible = false
	player.add_child(arrow)

	camera = Camera2D.new()
	camera.limit_left = 0
	camera.limit_top = 0
	camera.limit_right = int(LevelData.MAP_SIZE.x)
	camera.limit_bottom = int(LevelData.MAP_SIZE.y)
	camera.position_smoothing_enabled = true
	camera.position_smoothing_speed = 7.0
	player.add_child(camera)
	camera.make_current()
	camera.reset_smoothing()


func _build_door_fx() -> void:
	# ic kapilar (acilip kapanir) + ana kapi (faz 2'de acilir: soguk isik + iceri kar)
	var map_tex: Texture2D = load("res://assets/map.jpg")
	var defs := [
		{"r": Rect2(665, 488, 53, 62), "front": false},   # yatak odasi kapisi
		{"r": Rect2(1190, 488, 50, 62), "front": false},  # oturma odasi kapisi
		{"r": Rect2(864, 690, 54, 65), "front": false},   # banyo kapisi
		{"r": Rect2(1190, 775, 54, 83), "front": true},   # ana kapi
	]
	for d in defs:
		var door := Door.new()
		var is_front: bool = d["front"]
		door.setup(map_tex, d["r"], true, Color(0.78, 0.88, 1.0) if is_front else Color(0.06, 0.04, 0.03), is_front)
		world.add_child(door)
		doors.append(door)
		if is_front:
			front_door = door
			door.locked = true
	door_light = Sprite2D.new()
	door_light.texture = Fx.glow_tex()
	door_light.material = Fx.additive()
	door_light.position = LevelData.DOOR_POS + Vector2(0, -20)
	door_light.scale = Vector2(2.6, 2.2)
	door_light.modulate = Color(0.7, 0.85, 1.0, 0.0)
	world.add_child(door_light)
	door_snow = CPUParticles2D.new()
	door_snow.amount = 36
	door_snow.lifetime = 1.6
	door_snow.direction = Vector2(0, -1)
	door_snow.spread = 40.0
	door_snow.gravity = Vector2(0, -20)
	door_snow.initial_velocity_min = 60.0
	door_snow.initial_velocity_max = 150.0
	door_snow.scale_amount_min = 0.05
	door_snow.scale_amount_max = 0.2
	door_snow.texture = Fx.glow_tex()
	door_snow.emission_shape = CPUParticles2D.EMISSION_SHAPE_RECTANGLE
	door_snow.emission_rect_extents = Vector2(24, 4)
	var ramp := Gradient.new()
	ramp.set_color(0, Color(0.95, 0.98, 1.0, 0.0))
	ramp.add_point(0.2, Color(0.95, 0.98, 1.0, 0.6))
	ramp.set_color(ramp.get_point_count() - 1, Color(0.95, 0.98, 1.0, 0.0))
	door_snow.color_ramp = ramp
	door_snow.position = LevelData.DOOR_POS + Vector2(0, 20)
	door_snow.emitting = false
	world.add_child(door_snow)


func _spawn_items() -> void:
	var valid: Array = []
	for p in LevelData.ITEM_POINTS:
		if LevelData.is_free(LevelData.feet_rect(p), true):
			valid.append(p)
	valid.shuffle()
	var defs: Array = ITEM_DEFS.duplicate()
	defs.shuffle()
	var picked: Array = []
	for md in [170.0, 120.0, 70.0, 0.0]:
		for p in valid:
			if picked.size() >= ITEM_COUNT:
				break
			if picked.has(p):
				continue
			var ok := true
			for q in picked:
				if (p as Vector2).distance_to(q) < md:
					ok = false
					break
			if ok:
				picked.append(p)
	for i in range(ITEM_COUNT):
		var d: Dictionary = defs[i]
		chosen.append(d)
		var it := ItemPickup.new()
		it.setup(d, load("res://assets/items/%s.png" % d["id"]))
		it.position = picked[i]
		items_root.add_child(it)
		items.append(it)


func _spawn_survivors() -> void:
	for id in Dialogues.ORDER:
		var sv := Survivor.new()
		sv.setup(id)
		sv.position = LevelData.SURVIVORS[id]
		survivors_root.add_child(sv)
		survivors.append(sv)


func _build_tv_layer() -> void:
	tv_layer = CanvasLayer.new()
	tv_layer.layer = 3
	tv_layer.visible = false
	add_child(tv_layer)
	tv_screen = TVScreen.new()
	tv_screen.set_anchors_preset(Control.PRESET_FULL_RECT)
	tv_screen.mouse_filter = Control.MOUSE_FILTER_IGNORE
	tv_layer.add_child(tv_screen)
	tv_static = ColorRect.new()
	tv_static.set_anchors_preset(Control.PRESET_FULL_RECT)
	tv_static.mouse_filter = Control.MOUSE_FILTER_IGNORE
	tv_static_mat = ShaderMaterial.new()
	tv_static_mat.shader = load("res://shaders/tv_static.gdshader")
	tv_static.material = tv_static_mat
	tv_static.visible = false
	tv_layer.add_child(tv_static)


func _build_weather() -> void:
	weather = Weather.new()
	add_child(weather)
	weather.gust_started.connect(_on_gust)


func _build_post() -> void:
	post_layer = CanvasLayer.new()
	post_layer.layer = 5
	add_child(post_layer)
	var r := ColorRect.new()
	r.set_anchors_preset(Control.PRESET_FULL_RECT)
	r.mouse_filter = Control.MOUSE_FILTER_IGNORE
	post_mat = ShaderMaterial.new()
	post_mat.shader = load("res://shaders/post.gdshader")
	r.material = post_mat
	post_layer.add_child(r)


func _mk_label(txt: String, size: int, col: Color, outline: int = 6) -> Label:
	var l := Label.new()
	l.text = txt
	l.add_theme_font_size_override("font_size", size)
	l.add_theme_color_override("font_color", col)
	l.add_theme_color_override("font_outline_color", Color(0, 0, 0, 0.95))
	l.add_theme_constant_override("outline_size", outline)
	l.mouse_filter = Control.MOUSE_FILTER_IGNORE
	return l


func _panel_style(bg: Color, border: Color, radius: int = 10) -> StyleBoxFlat:
	var sb := StyleBoxFlat.new()
	sb.bg_color = bg
	sb.border_color = border
	sb.set_border_width_all(2)
	sb.set_corner_radius_all(radius)
	return sb


func _build_hud() -> void:
	hud = CanvasLayer.new()
	hud.layer = 10
	add_child(hud)
	hud_root = Control.new()
	hud_root.set_anchors_preset(Control.PRESET_FULL_RECT)
	hud_root.mouse_filter = Control.MOUSE_FILTER_IGNORE
	hud_root.modulate = Color(1, 1, 1, 0)
	hud.add_child(hud_root)

	# --- sol ust: sayac paneli
	var tp := Panel.new()
	tp.position = Vector2(16, 16)
	tp.size = Vector2(300, 128)
	tp.add_theme_stylebox_override("panel", _panel_style(Color(0.04, 0.07, 0.12, 0.82), Color(0.4, 0.7, 1.0, 0.8)))
	hud_root.add_child(tp)
	var cap := _mk_label("KALAN SÜRE", 14, Color(0.6, 0.8, 1.0), 3)
	cap.position = Vector2(14, 6)
	tp.add_child(cap)
	timer_label = _mk_label("02:00.0", 46, Color.WHITE, 8)
	timer_label.position = Vector2(12, 20)
	tp.add_child(timer_label)
	var bar_bg := ColorRect.new()
	bar_bg.color = Color(0, 0, 0, 0.6)
	bar_bg.position = Vector2(14, 80)
	bar_bg.size = Vector2(272, 10)
	tp.add_child(bar_bg)
	bar_fill = ColorRect.new()
	bar_fill.color = Color(0.4, 0.8, 1.0)
	bar_fill.position = Vector2(14, 80)
	bar_fill.size = Vector2(272, 10)
	tp.add_child(bar_fill)
	temp_label = _mk_label("SICAKLIK: +21°C", 18, Color(1.0, 0.85, 0.5), 4)
	temp_label.position = Vector2(14, 96)
	tp.add_child(temp_label)

	# --- gorev bolumu (sayacin altinda, metin sarilir; envanter paneline tasmaz)
	var op := Panel.new()
	op.position = Vector2(16, 152)
	op.size = Vector2(300, 96)
	op.add_theme_stylebox_override("panel", _panel_style(Color(0.04, 0.07, 0.12, 0.82), Color(1.0, 0.75, 0.4, 0.8)))
	hud_root.add_child(op)
	var ocap := _mk_label("GÖREV", 14, Color(1.0, 0.8, 0.5), 3)
	ocap.position = Vector2(14, 6)
	op.add_child(ocap)
	obj_label = _mk_label("", 18, Color(1, 1, 1), 4)
	obj_label.position = Vector2(14, 28)
	obj_label.size = Vector2(274, 62)
	obj_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	op.add_child(obj_label)

	# --- sag ust: ENVANTER
	var w := 5 * 58 + 20
	var h := 2 * 58 + 52
	inv_panel = Panel.new()
	inv_panel.position = Vector2(VIEW.x - w - 16, 16)
	inv_panel.size = Vector2(w, h)
	inv_panel.add_theme_stylebox_override("panel", _panel_style(Color(0.08, 0.06, 0.04, 0.85), Color(1.0, 0.8, 0.4, 0.85)))
	hud_root.add_child(inv_panel)
	inv_title = _mk_label("EŞYALAR  0/%d" % ITEM_COUNT, 18, Color(1.0, 0.9, 0.6), 4)
	inv_title.position = Vector2(12, 8)
	inv_panel.add_child(inv_title)
	for i in range(ITEM_COUNT):
		var slot := Panel.new()
		slot.size = Vector2(54, 54)
		slot.position = Vector2(10 + (i % 5) * 58, 40 + (i / 5) * 58)
		slot.pivot_offset = Vector2(27, 27)
		slot.add_theme_stylebox_override("panel", _panel_style(Color(0.0, 0.0, 0.0, 0.55), Color(0.5, 0.4, 0.25, 0.7), 6))
		inv_panel.add_child(slot)
		var icon := TextureRect.new()
		icon.texture = load("res://assets/items/%s.png" % chosen[i]["id"])
		icon.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
		icon.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
		icon.texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
		icon.position = Vector2(3, 3)
		icon.size = Vector2(48, 48)
		icon.modulate = Color(0.0, 0.0, 0.0, 0.55)
		icon.mouse_filter = Control.MOUSE_FILTER_IGNORE
		slot.add_child(icon)
		slots.append(slot)

	# --- kurtarilanlar paneli (envanterin altinda)
	var rp := Panel.new()
	rp.position = Vector2(VIEW.x - w - 16, 16 + h + 8)
	rp.size = Vector2(w, 100)
	rp.add_theme_stylebox_override("panel", _panel_style(Color(0.03, 0.08, 0.08, 0.85), Color(0.4, 0.9, 0.8, 0.8)))
	hud_root.add_child(rp)
	rescue_title = _mk_label("KURTARILANLAR  0/%d" % SURVIVOR_COUNT, 16, Color(0.6, 1.0, 0.9), 4)
	rescue_title.position = Vector2(12, 6)
	rp.add_child(rescue_title)
	for i in range(SURVIVOR_COUNT):
		var sv: Survivor = survivors[i]
		var rs := Panel.new()
		rs.size = Vector2(54, 62)
		rs.position = Vector2(10 + i * 58, 32)
		rs.pivot_offset = Vector2(27, 31)
		rs.add_theme_stylebox_override("panel", _panel_style(Color(0, 0, 0, 0.55), Color(0.2, 0.4, 0.4, 0.7), 6))
		rp.add_child(rs)
		var ic := TextureRect.new()
		ic.texture = sv.tex[0]
		ic.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
		ic.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
		ic.texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
		ic.position = Vector2(2, 2)
		ic.size = Vector2(50, 58)
		ic.modulate = Color(0, 0, 0, 0.55)
		ic.mouse_filter = Control.MOUSE_FILTER_IGNORE
		rs.add_child(ic)
		rescue_slots.append(rs)

	# --- orta mesajlar
	msg_label = _mk_label("", 26, Color(1, 0.95, 0.6), 8)
	msg_label.position = Vector2(340, 24)
	msg_label.size = Vector2(600, 90)
	msg_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	msg_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	msg_label.modulate.a = 0.0
	hud_root.add_child(msg_label)

	hint_label = _mk_label("WASD / Ok tuşları: Hareket   •   Shift: Koş   •   R: Yeniden başla", 15, Color(0.85, 0.9, 1.0), 4)
	hint_label.position = Vector2(0, VIEW.y - 34)
	hint_label.size = Vector2(VIEW.x, 24)
	hint_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	hud_root.add_child(hint_label)

	# --- buyuk yazi (hud_root disinda; intro sirasinda da gorunebilsin)
	big_label = _mk_label("", 84, Color.WHITE, 14)
	big_label.position = Vector2(0, 250)
	big_label.size = Vector2(VIEW.x, 120)
	big_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	big_label.pivot_offset = Vector2(VIEW.x * 0.5, 60)
	big_label.modulate.a = 0.0
	hud.add_child(big_label)
	sub_label = _mk_label("", 28, Color(0.9, 0.95, 1.0), 8)
	sub_label.position = Vector2(0, 372)
	sub_label.size = Vector2(VIEW.x, 120)
	sub_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	sub_label.modulate.a = 0.0
	hud.add_child(sub_label)

	# --- ekran kenari kazazede gostergeleri + diyalog kutusu
	edge = EdgeMarkers.new()
	edge.survivors = survivors
	edge.camera = camera
	edge.player = player
	hud.add_child(edge)
	dialogue = DialogueBox.new()
	hud.add_child(dialogue)
	dialogue.finished.connect(_finish_rescue)


func _build_fade() -> void:
	var cl := CanvasLayer.new()
	cl.layer = 20
	add_child(cl)
	fade_rect = ColorRect.new()
	fade_rect.color = Color(0, 0, 0, 1)
	fade_rect.set_anchors_preset(Control.PRESET_FULL_RECT)
	fade_rect.mouse_filter = Control.MOUSE_FILTER_IGNORE
	cl.add_child(fade_rect)


# ====================================================================== INTRO (TV HABERI)
func _t() -> Tween:
	var tw := create_tween()
	intro_tweens.append(tw)
	return tw


func _wait(sec: float) -> void:
	var end := Time.get_ticks_msec() + int(sec * 1000.0)
	while Time.get_ticks_msec() < end and not skip_intro:
		await get_tree().process_frame


func _run_intro() -> void:
	state = State.INTRO
	player.controllable = false
	player.facing = Vector2.UP
	Sfx.start_loop("wind", -22.0)
	set_big("", Color.WHITE)

	# 1) siyahtan acilis; sakin aksam
	var tw := _t()
	tw.tween_property(fade_rect, "color:a", 0.0, 1.2)
	sub_label.text = "Sakin bir cumartesi akşamı... Televizyon açık."
	_t().tween_property(sub_label, "modulate:a", 1.0, 0.8)
	await _wait(2.6)
	if skip_intro:
		_finish_intro()
		return
	_t().tween_property(sub_label, "modulate:a", 0.0, 0.5)

	# 2) televizyon cizirtisi, kamera TV'ye yaklasir
	Sfx.play("jingle", -6.0)
	Sfx.start_loop("static", -26.0)
	_t().tween_property(self, "tv_amount", 1.0, 0.8)
	_t().tween_property(self, "tv_alert", 1.0, 1.4)
	var tv_c := LevelData.TV_RECT.get_center()
	var z := _t()
	z.set_parallel(true)
	z.tween_property(camera, "zoom", Vector2(2.3, 2.3), 1.7).set_trans(Tween.TRANS_CUBIC).set_ease(Tween.EASE_IN_OUT)
	z.tween_property(self, "cam_off", tv_c - LevelData.SPAWN_POS, 1.7).set_trans(Tween.TRANS_CUBIC).set_ease(Tween.EASE_IN_OUT)
	await _wait(1.8)
	if skip_intro:
		_finish_intro()
		return

	# 3) tam ekran haber yayini
	tv_layer.visible = true
	tv_static.visible = true
	tv_static_mat.set_shader_parameter("amount", 1.0)
	fx_tv = 1.0
	fx_glitch = 1.0
	Sfx.play("whoosh", -6.0)
	await _wait(0.35)
	if skip_intro:
		_finish_intro()
		return
	tv_static.visible = false
	Sfx.stop_loop("static")
	Sfx.play("eas", -8.0)
	tv_screen.caption = ""
	fx_glitch = 0.25
	_t().tween_property(tv_screen, "shift", 0.85, 12.0)
	await _wait(1.0)

	var lines := [
		"Uluslararası Uzay Ajansı'ndan acil açıklama!",
		"Dünya yörüngesinden saptı! Güneş'ten uzaklaşıyoruz!",
		"2 DAKİKA içinde gezegendeki HER ŞEY donacak!",
		"Herkes en yakın sığınağa gitsin! Yayın kesiliyor..."
	]
	for li in range(lines.size()):
		if skip_intro:
			_finish_intro()
			return
		var line: String = lines[li]
		tv_screen.caption = line
		tv_screen.typed = 0.0
		last_typed = 0
		var tt := _t()
		tt.tween_property(tv_screen, "typed", float(line.length()), 0.036 * line.length())
		if li == 1:
			Sfx.start_loop("rumble_l", -20.0)
		if li >= 1:
			fx_glitch = 0.5 + li * 0.15
			shake_base = 2.0 + li * 2.0
		if li == 2:
			tv_screen.alert = 1.0
			Sfx.play("eas", -10.0)
			_t().tween_property(tv_screen, "ice", 0.7, 3.0)
		await _wait(0.036 * line.length() + 1.1)
	if skip_intro:
		_finish_intro()
		return

	# 4) yayin kesilir
	fx_glitch = 1.0
	shake_kick = 24.0
	Sfx.play("rumble", -2.0)
	Sfx.play("crack", -4.0)
	fx_flash = 1.0
	_t().tween_property(self, "fx_flash", 0.0, 0.5)
	tv_static.visible = true
	tv_static_mat.set_shader_parameter("alert", 0.0)
	Sfx.start_loop("static", -20.0)
	tv_screen.caption = ""
	await _wait(1.0)
	if skip_intro:
		_finish_intro()
		return
	_finish_intro()


func _finish_intro() -> void:
	if state != State.INTRO:
		return
	for tw in intro_tweens:
		if tw != null and tw.is_valid():
			tw.kill()
	intro_tweens.clear()
	Sfx.stop_loop("static")
	Sfx.stop_loop("rumble_l")
	tv_layer.visible = false
	fade_rect.color.a = 0.0
	tv_amount = 0.5
	tv_alert = 0.0
	fx_glitch = 0.0
	fx_tv = 0.0
	fx_flash = 0.0
	shake_base = 0.0
	sub_label.modulate.a = 0.0
	camera.zoom = Vector2.ONE
	cam_off = Vector2.ZERO
	player.facing = Vector2.DOWN

	# GO!
	Sfx.play("rumble", -6.0)
	Sfx.play("sting", -4.0)
	shake_kick = 14.0
	fx_flash = 0.8
	var tw2 := create_tween()
	tw2.tween_property(self, "fx_flash", 0.0, 0.6)
	set_big("EŞYALARI TOPLA!", Color(1.0, 0.45, 0.3))
	big_label.scale = Vector2(2.2, 2.2)
	var tw3 := create_tween()
	tw3.set_parallel(true)
	tw3.tween_property(big_label, "scale", Vector2.ONE, 0.35).set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_OUT)
	tw3.tween_property(big_label, "modulate:a", 1.0, 0.15)
	tw3.chain().tween_interval(0.9)
	tw3.chain().tween_property(big_label, "modulate:a", 0.0, 0.5)
	create_tween().tween_property(hud_root, "modulate:a", 1.0, 0.6)

	state = State.PLAY
	phase = 1
	time_left = TOTAL_TIME
	player.controllable = true
	Sfx.start_loop("drone", -14.0)
	Sfx.start_loop("action", -12.0)
	show_msg("2 dakikan var! Evdeki 10 eşyayı topla. Kapı kilitli!", Color(1.0, 0.95, 0.6), 4.0)


# ====================================================================== OYUN DONGUSU
func _process(delta: float) -> void:
	denied_cd = maxf(0.0, denied_cd - delta)
	_update_camera(delta)
	_update_tv_screen()
	_update_typing_sfx()
	if state == State.PLAY or state == State.DIALOGUE:
		_play_tick(delta)
	_push_post()


func _update_camera(delta: float) -> void:
	shake_kick = maxf(0.0, shake_kick - delta * 28.0)
	var m := shake_base + shake_kick
	var j := Vector2(randf_range(-1.0, 1.0), randf_range(-1.0, 1.0)) * m
	camera.offset = cam_off + j


func _update_tv_screen() -> void:
	tv_mat.set_shader_parameter("amount", tv_amount)
	tv_mat.set_shader_parameter("alert", tv_alert)
	tv_static_mat.set_shader_parameter("alert", 0.0)


func _update_typing_sfx() -> void:
	if not tv_layer.visible:
		return
	var n := int(tv_screen.typed)
	if n != last_typed:
		if n % 2 == 0 and n < tv_screen.caption.length():
			Sfx.play("type", -14.0, randf_range(0.9, 1.2))
		last_typed = n


func _push_post() -> void:
	var storm := weather.intensity()
	post_mat.set_shader_parameter("glitch", fx_glitch)
	post_mat.set_shader_parameter("cold", clampf(fx_cold + weather.outside_k * 0.25, 0.0, 1.0))
	post_mat.set_shader_parameter("frost", fx_frost + frost_boost)
	post_mat.set_shader_parameter("flash", fx_flash)
	post_mat.set_shader_parameter("alarm", fx_alarm)
	post_mat.set_shader_parameter("tv", fx_tv)
	post_mat.set_shader_parameter("storm", storm)
	post_mat.set_shader_parameter("dark", ambience.blackout_k * 0.5)


func _play_tick(delta: float) -> void:
	var dt := delta * (DIALOGUE_TIME_SCALE if state == State.DIALOGUE else 1.0)
	time_left -= dt
	if time_left <= 0.0:
		time_left = 0.0
		_update_hud()
		_lose()
		return

	var ratio := 1.0 - time_left / TOTAL_TIME
	fx_cold = smoothstep(0.0, 1.0, ratio)
	fx_frost = pow(ratio, 1.7) * 1.0
	player.set_cold(fx_cold)
	for s in survivors:
		(s as Survivor).set_cold(fx_cold)
	weather.set_progress(ratio)
	weather.set_outside(player.outside)
	ambience.update_state(ratio, 1.0 if time_left <= 20.0 else 0.0)
	var base_col := Color(1, 1, 1).lerp(Color(0.62, 0.74, 1.0), clampf(ratio * 0.9, 0.0, 1.0))
	var out_col := Color(1, 1, 1).lerp(Color(0.8, 0.88, 1.0), weather.outside_k)
	world_mod.color = base_col * out_col

	# ruzgar sesi: iceride kisik, disarida gurultulu
	Sfx.set_loop("wind", lerpf(-26.0, -8.0, weather.outside_k) + ratio * 4.0, 1.0 + ratio * 0.18)

	# kapi isigi / kar (faz 2 ve sonrasi)
	var fo := front_door.open_t if front_door != null else 0.0
	door_light.modulate = Color(0.7, 0.85, 1.0, door_open_k * (0.12 + 0.4 * fo) * (0.85 + 0.15 * sin(Time.get_ticks_msec() * 0.01)))
	door_snow.emitting = door_open_k > 0.5 and fo > 0.2

	# iz sur (takipciler icin)
	if player.moving and (trail.is_empty() or player.position.distance_to(trail[trail.size() - 1]) > 7.0):
		trail.append(player.position)
		if trail.size() > 600:
			trail.pop_front()
	_update_followers(delta)
	_tick_doors(delta)

	if state == State.PLAY:
		_check_items()
		_check_gate_and_hatch()
		_check_rescue()
	_random_events(delta, ratio)
	_countdown_fx(delta)
	_warnings()
	_update_arrow()
	_update_hud()
	edge.enabled = phase == 2 and state == State.PLAY


func _tick_doors(delta: float) -> void:
	var actors: Array = [player.position]
	for sv in followers:
		actors.append((sv as Survivor).position)
	for d in doors:
		(d as Door).tick(delta, actors)


func _check_items() -> void:
	for it in items:
		var item: ItemPickup = it
		if item.collected:
			continue
		if player.position.distance_to(item.position) < 42.0:
			_collect(item)


func _check_gate_and_hatch() -> void:
	if phase == 1 and player.position.distance_to(LevelData.DOOR_POS + Vector2(0, -8)) < 56.0 and denied_cd <= 0.0:
		denied_cd = 1.6
		Sfx.play("denied", -4.0)
		shake_kick = 3.0
		show_msg("Kapı donmuş, açılmıyor! Önce eşyaları topla (%d/%d)" % [collected, ITEM_COUNT], Color(1.0, 0.5, 0.4), 2.0)
	var hd := player.position.distance_to(LevelData.HATCH_ENTER)
	if hd < 38.0:
		if phase >= 3:
			_enter_hatch()
		elif denied_cd <= 0.0:
			denied_cd = 1.8
			Sfx.play("denied", -4.0)
			if phase == 1:
				show_msg("Sığınak KİLİTLİ! Önce eşyaları topla (%d/%d)" % [collected, ITEM_COUNT], Color(1.0, 0.4, 0.35), 2.0)
			else:
				show_msg("Dışarıdakileri bırakmam! Kurtarıldı: %d/%d" % [rescued_n, SURVIVOR_COUNT], Color(1.0, 0.4, 0.35), 2.2)


func _check_rescue() -> void:
	if phase != 2:
		return
	for s in survivors:
		var sv: Survivor = s
		if sv.rescued:
			continue
		if player.position.distance_to(sv.position) < 64.0:
			_begin_dialogue(sv)
			return


func _update_followers(delta: float) -> void:
	for i in range(followers.size()):
		var sv: Survivor = followers[i]
		var idx: int = trail.size() - 1 - (i + 1) * 8
		var target: Vector2 = player.position + Vector2(-14.0 * float(i + 1), 8.0)
		if idx >= 0:
			target = trail[idx]
		sv.follow(delta, target)


func _random_events(delta: float, ratio: float) -> void:
	# deprem sarsintilari: giderek sikilasir
	rumble_timer -= delta
	if rumble_timer <= 0.0:
		rumble_timer = randf_range(8.0, 13.0) * (1.0 - ratio * 0.45)
		_quake()
	# buzun inlemesi
	groan_timer -= delta
	if groan_timer <= 0.0:
		groan_timer = randf_range(14.0, 22.0)
		Sfx.play("ice_groan", -10.0, randf_range(0.85, 1.1))
		fx_glitch = maxf(fx_glitch, 0.35)
		create_tween().tween_property(self, "fx_glitch", 0.0, 0.5)


func _quake() -> void:
	shake_kick = 16.0
	Sfx.play("rumble", -8.0)
	Sfx.play("crack", -14.0)
	fx_flash = 0.25
	create_tween().tween_property(self, "fx_flash", 0.0, 0.3)
	ambience.blackout(0.5)
	if not player.outside:
		weather.quake()
	player.stumble(0.4)
	fx_glitch = maxf(fx_glitch, 0.6)
	create_tween().tween_property(self, "fx_glitch", 0.0, 0.6)


func _countdown_fx(delta: float) -> void:
	var sec := int(ceil(time_left))
	if sec != last_sec:
		last_sec = sec
		if sec <= 10:
			Sfx.play("tick", -2.0, 1.0 + (10 - sec) * 0.04)
			_pulse_timer()
	# kalp atisi: son 40 saniyede hizlanir
	if time_left <= 40.0:
		beat_timer -= delta
		if beat_timer <= 0.0:
			beat_timer = lerpf(0.95, 0.45, clampf((40.0 - time_left) / 40.0, 0.0, 1.0))
			Sfx.play("beat", -3.0)
			shake_kick = maxf(shake_kick, 1.5)
	if time_left <= 20.0:
		fx_alarm = 0.5 + 0.5 * sin(Time.get_ticks_msec() * 0.008)
		Sfx.start_loop("siren", -20.0)
		Sfx.set_loop("action", -9.0, 1.12)
	else:
		fx_alarm = 0.0


func _on_gust() -> void:
	if state == State.PLAY or state == State.DIALOGUE:
		Sfx.play("gust", -12.0 + weather.progress * 4.0, randf_range(0.85, 1.1))
		shake_kick = maxf(shake_kick, 3.0)


func _warnings() -> void:
	if time_left <= 90.0 and not warned.has(90):
		warned[90] = true
		_cold_wave()
		show_msg("Sıcaklık hızla düşüyor!", Color(0.6, 0.85, 1.0), 2.2)
	if time_left <= 60.0 and not warned.has(60):
		warned[60] = true
		_cold_wave()
		show_msg("1 DAKİKA kaldı! Pencerelerde buz oluşuyor!", Color(1.0, 0.85, 0.4), 2.5)
		Sfx.play("crack", -6.0)
	if time_left <= 30.0 and not warned.has(30):
		warned[30] = true
		_cold_wave()
		show_msg("30 SANİYE! Hızlı ol!", Color(1.0, 0.5, 0.3), 2.5)
		Sfx.play("crack", -3.0)
		shake_kick = 14.0
	if time_left <= 10.0 and not warned.has(10):
		warned[10] = true
		show_msg("10 SANİYE!!!", Color(1.0, 0.25, 0.2), 2.0)


# Buz dalgasi: ani soguk, ekran donar, isiklar soner
func _cold_wave() -> void:
	Sfx.play("ice_groan", -4.0)
	Sfx.play("gust", -6.0)
	shake_kick = 12.0
	fx_flash = 0.5
	create_tween().tween_property(self, "fx_flash", 0.0, 0.7)
	frost_boost = 0.35
	create_tween().tween_property(self, "frost_boost", 0.0, 2.4)
	ambience.blackout(0.9)


func _pulse_timer() -> void:
	timer_label.pivot_offset = Vector2(80, 25)
	timer_label.scale = Vector2(1.25, 1.25)
	create_tween().tween_property(timer_label, "scale", Vector2.ONE, 0.3).set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_OUT)


func _update_arrow() -> void:
	var target := LevelData.HATCH_POS
	if phase == 1:
		var best := 1e9
		for it in items:
			var item: ItemPickup = it
			if item.collected:
				continue
			var dd := player.position.distance_to(item.position)
			if dd < best:
				best = dd
				target = item.position
		if player.position.distance_to(LevelData.DOOR_POS) < 0.0:
			target = LevelData.DOOR_POS
	elif phase == 2:
		var best2 := 1e9
		for s in survivors:
			var sv: Survivor = s
			if sv.rescued:
				continue
			var d2 := player.position.distance_to(sv.position)
			if d2 < best2:
				best2 = d2
				target = sv.position
		# disaridaki hedefe giderken once kapiya yonlendir
		if not player.outside and LevelData.is_outside(target):
			target = LevelData.DOOR_POS
	var dir := (target - player.position)
	var dist := dir.length()
	if dist < 90.0:
		arrow.visible = false
		return
	dir = dir.normalized()
	arrow.visible = true
	arrow.position = Vector2(0, -34) + dir * (78.0 + sin(Time.get_ticks_msec() * 0.008) * 4.0)
	arrow.rotation = dir.angle()
	if phase >= 3:
		arrow.color = Color(0.4, 1.0, 0.55, 0.9)
	elif phase == 2:
		arrow.color = Color(1.0, 0.6, 0.25, 0.9)
	else:
		arrow.color = Color(1.0, 0.9, 0.3, 0.8)


func _update_hud() -> void:
	var t := time_left
	var m := floori(t / 60.0)
	var s := int(t) % 60
	var ds := int((t - floor(t)) * 10.0)
	timer_label.text = "%02d:%02d.%d" % [m, s, ds]
	var frac := t / TOTAL_TIME
	bar_fill.size.x = 272.0 * frac
	var col := Color(0.4, 0.8, 1.0)
	if t <= 30.0:
		col = Color(1.0, 0.8, 0.3)
	if t <= 10.0:
		col = Color(1.0, 0.25, 0.2)
	bar_fill.color = col
	timer_label.add_theme_color_override("font_color", col.lerp(Color.WHITE, 0.45) if t > 10.0 else Color(1.0, 0.3, 0.25))
	var temp := lerpf(21.0, -72.0, 1.0 - frac)
	temp_label.text = "SICAKLIK: %+d°C" % int(round(temp))
	temp_label.add_theme_color_override("font_color", Color(1.0, 0.85, 0.5).lerp(Color(0.5, 0.8, 1.0), 1.0 - frac))
	if phase == 1:
		obj_label.text = "Hedef: evdeki eşyaları topla (%d/%d)" % [collected, ITEM_COUNT]
		obj_label.add_theme_color_override("font_color", Color(1, 1, 1))
	elif phase == 2:
		obj_label.text = "Dışarıdakileri kurtar (%d/%d). Yardım seslerini takip et!" % [rescued_n, SURVIVOR_COUNT]
		obj_label.add_theme_color_override("font_color", Color(1.0, 0.75, 0.4))
	else:
		obj_label.text = "Herkes hazır! Sağ üst odadaki sığınağa koş!"
		obj_label.add_theme_color_override("font_color", Color(0.5, 1.0, 0.6))


# ====================================================================== ESYA TOPLAMA
func _collect(item: ItemPickup) -> void:
	item.collected = true
	var idx := chosen.find(item.def)
	collected += 1
	Sfx.play("pickup", -3.0, randf_range(0.95, 1.1))
	player.pop()
	Fx.burst(world, item.position + Vector2(0, -24), Color(1.0, 0.9, 0.4), 24, 170.0)
	Fx.ring(world, item.position + Vector2(0, -20), Color(1.0, 0.9, 0.4, 0.8), 70.0, 0.5, 3.0)
	_float_text("+ " + String(item.def["name"]), item.position + Vector2(0, -50), Color(1.0, 0.95, 0.5))

	# esya ekranda envanter yuvasina ucar
	var start: Vector2 = item.icon.get_global_transform_with_canvas().origin
	var fly := Sprite2D.new()
	fly.texture = item.tex
	fly.position = start
	hud.add_child(fly)
	item.visible = false
	var slot: Panel = slots[idx]
	var target := inv_panel.position + slot.position + slot.size * 0.5
	Sfx.play("whoosh", -12.0, 1.2)
	var tw := create_tween()
	tw.set_parallel(true)
	tw.tween_property(fly, "position", target, 0.55).set_trans(Tween.TRANS_CUBIC).set_ease(Tween.EASE_IN)
	tw.tween_property(fly, "scale", Vector2(0.95, 0.95), 0.55)
	tw.tween_property(fly, "rotation", TAU, 0.55)
	tw.chain().tween_callback(_slot_arrived.bind(idx, fly))

	if collected >= ITEM_COUNT:
		_start_phase2()


func _slot_arrived(idx: int, fly: Sprite2D) -> void:
	if is_instance_valid(fly):
		fly.queue_free()
	var slot: Panel = slots[idx]
	var icon: TextureRect = slot.get_child(0)
	icon.modulate = Color.WHITE
	slot.add_theme_stylebox_override("panel", _panel_style(Color(0.25, 0.18, 0.05, 0.9), Color(1.0, 0.85, 0.35, 1.0), 6))
	slot.scale = Vector2(1.4, 1.4)
	create_tween().tween_property(slot, "scale", Vector2.ONE, 0.35).set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_OUT)
	Sfx.play("slot", -6.0, 1.0 + collected * 0.04)
	inv_title.text = "EŞYALAR  %d/%d" % [collected, ITEM_COUNT]
	Fx.burst(hud, slot.global_position + slot.size * 0.5, Color(1.0, 0.85, 0.4), 14, 110.0, 0.5, 0.1)


func _float_text(txt: String, pos: Vector2, col: Color) -> void:
	var l := _mk_label(txt, 20, col, 6)
	l.position = pos - Vector2(130, 0)
	l.size = Vector2(260, 30)
	l.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	world.add_child(l)
	var tw := create_tween()
	tw.set_parallel(true)
	tw.tween_property(l, "position:y", pos.y - 50.0, 1.0).set_trans(Tween.TRANS_CUBIC).set_ease(Tween.EASE_OUT)
	tw.tween_property(l, "modulate:a", 0.0, 1.0).set_delay(0.4)
	tw.chain().tween_callback(l.queue_free)


# ====================================================================== ASAMA 2: DISARIDAN YARDIM SESLERI
func _start_phase2() -> void:
	phase = 2
	Sfx.play("sting", -2.0)
	Sfx.play("door_open", -3.0)
	Sfx.play("gust", -4.0)
	shake_kick = 16.0
	fx_flash = 0.5
	create_tween().tween_property(self, "fx_flash", 0.0, 0.6)
	fx_glitch = 0.8
	create_tween().tween_property(self, "fx_glitch", 0.0, 0.8)
	ambience.blackout(0.7)
	player.gate_closed = false
	# ana kapi acilir: soguk isik + iceri kar
	create_tween().tween_property(self, "door_open_k", 1.0, 0.8)
	front_door.locked = false
	front_door.quiet = false
	Fx.puff(world, LevelData.DOOR_POS + Vector2(0, 10), 30, 130.0, 0.5)
	Fx.ring(world, LevelData.DOOR_POS, Color(0.8, 0.92, 1.0, 0.8), 200.0, 1.2, 4.0)
	for i in range(survivors.size()):
		var sv: Survivor = survivors[i]
		var tw := create_tween()
		tw.tween_interval(0.6 + 0.5 * float(i))
		tw.tween_callback(sv.start_calling)
	set_big("YARDIM SESLERİ!", Color(1.0, 0.65, 0.3))
	big_label.scale = Vector2(2.0, 2.0)
	sub_label.text = "Dışarıda mahsur kalanlar var..."
	sub_label.modulate.a = 0.0
	var bt := create_tween()
	bt.set_parallel(true)
	bt.tween_property(big_label, "scale", Vector2.ONE, 0.35).set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_OUT)
	bt.tween_property(big_label, "modulate:a", 1.0, 0.1)
	bt.tween_property(sub_label, "modulate:a", 1.0, 0.4).set_delay(0.3)
	bt.chain().tween_interval(1.4)
	bt.chain().tween_property(big_label, "modulate:a", 0.0, 0.5)
	bt.parallel().tween_property(sub_label, "modulate:a", 0.0, 0.5)
	show_msg("Kapı açıldı! Dışarıdan çığlıklar geliyor — herkesi bul, hepsi olmadan sığınak açılmaz!", Color(1.0, 0.8, 0.45), 4.5)


func _begin_dialogue(sv: Survivor) -> void:
	state = State.DIALOGUE
	current_sv = sv
	player.controllable = false
	player.moving = false
	var d := sv.position - player.position
	if absf(d.x) > absf(d.y):
		player.facing = Vector2(signf(d.x), 0.0)
	else:
		player.facing = Vector2(0.0, signf(d.y))
	sv.calling = false
	sv.voice.stop()
	sv.queue_redraw()
	Sfx.play("whoosh", -14.0, 0.8)
	# kamera ikisinin arasina yaklasir
	var zt := create_tween()
	zt.set_parallel(true)
	zt.tween_property(camera, "zoom", Vector2(1.35, 1.35), 0.4).set_trans(Tween.TRANS_CUBIC).set_ease(Tween.EASE_OUT)
	zt.tween_property(self, "cam_off", d * 0.5, 0.4).set_trans(Tween.TRANS_CUBIC).set_ease(Tween.EASE_OUT)
	dialogue.start(sv.id, player.tex["front_idle"], sv.tex[0])


func _finish_rescue() -> void:
	if current_sv == null:
		return
	var sv: Survivor = current_sv
	current_sv = null
	rescued_n += 1
	sv.rescue()
	followers.append(sv)
	var i := survivors.find(sv)
	Sfx.play("rescue", -2.0)
	player.pop()
	var c := Color(0.5, 1.0, 0.7)
	Fx.burst(world, sv.position + Vector2(0, -40), c, 36, 210.0, 0.9, 0.14)
	Fx.ring(world, sv.position + Vector2(0, -34), Color(0.5, 1.0, 0.7, 0.9), 160.0, 1.0, 4.0)
	_float_text("+ %s kurtarıldı!" % String(Dialogues.DATA[sv.id]["name"]), sv.position + Vector2(0, -90), Color(0.6, 1.0, 0.75))
	# panel yuvasi dolar
	var rs: Panel = rescue_slots[i]
	var ic: TextureRect = rs.get_child(0)
	ic.modulate = Color.WHITE
	rs.add_theme_stylebox_override("panel", _panel_style(Color(0.05, 0.25, 0.2, 0.9), Color(0.5, 1.0, 0.85, 1.0), 6))
	rs.scale = Vector2(1.4, 1.4)
	create_tween().tween_property(rs, "scale", Vector2.ONE, 0.35).set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_OUT)
	rescue_title.text = "KURTARILANLAR  %d/%d" % [rescued_n, SURVIVOR_COUNT]
	# kamera geri
	var zt := create_tween()
	zt.set_parallel(true)
	zt.tween_property(camera, "zoom", Vector2.ONE, 0.4).set_trans(Tween.TRANS_CUBIC).set_ease(Tween.EASE_OUT)
	zt.tween_property(self, "cam_off", Vector2.ZERO, 0.4).set_trans(Tween.TRANS_CUBIC).set_ease(Tween.EASE_OUT)
	if state == State.DIALOGUE:
		state = State.PLAY
		player.controllable = true
	if rescued_n >= SURVIVOR_COUNT:
		_unlock_hatch()


func _unlock_hatch() -> void:
	phase = 3
	hatch.unlock()
	Sfx.play("hatch_open", -2.0)
	shake_kick = 8.0
	show_msg("HERKES SENİNLE! Sığınak açıldı — sağ üst odaya koş!", Color(0.5, 1.0, 0.6), 3.5)
	set_big("SIĞINAK AÇILDI!", Color(0.5, 1.0, 0.6))
	big_label.scale = Vector2(1.8, 1.8)
	var tw := create_tween()
	tw.set_parallel(true)
	tw.tween_property(big_label, "scale", Vector2.ONE, 0.3).set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_OUT)
	tw.tween_property(big_label, "modulate:a", 1.0, 0.1)
	tw.chain().tween_interval(0.8)
	tw.chain().tween_property(big_label, "modulate:a", 0.0, 0.5)


# ====================================================================== BITIS
func _enter_hatch() -> void:
	if ending:
		return
	ending = true
	state = State.ENTERING
	player.controllable = false
	player.moving = false
	arrow.visible = false
	edge.enabled = false
	Sfx.stop_loop("action")
	Sfx.stop_loop("drone")
	Sfx.stop_loop("siren")
	Sfx.play("whoosh", -4.0)
	var tw := create_tween()
	tw.tween_property(player, "position", LevelData.HATCH_POS + Vector2(0, 10), 0.4).set_trans(Tween.TRANS_QUAD).set_ease(Tween.EASE_OUT)
	tw.tween_callback(func():
		player.climb_mode = true
		Sfx.play("step", -6.0, 0.7)
	)
	tw.tween_property(player.body, "scale", Vector2(0.55, 0.55), 0.8).set_trans(Tween.TRANS_QUAD).set_ease(Tween.EASE_IN)
	tw.parallel().tween_property(player.body, "modulate:a", 0.0, 0.8)
	tw.parallel().tween_property(player.body, "position:y", 26.0, 0.8)
	tw.tween_callback(func():
		Sfx.play("jump", -4.0)
		Fx.puff(world, LevelData.HATCH_POS, 10, 50.0, 0.25)
	)
	# kurtarilanlar tek tek atlar
	for sv in followers:
		tw.tween_callback(_send_follower.bind(sv))
		tw.tween_interval(0.5)
	tw.tween_interval(0.5)
	tw.tween_callback(func():
		hatch.close_up()
		Sfx.play("hatch_close", -2.0)
		shake_kick = 10.0
		fx_flash = 0.6
		create_tween().tween_property(self, "fx_flash", 0.0, 0.8)
	)
	tw.tween_interval(0.9)
	tw.tween_callback(_win)


func _send_follower(sv: Survivor) -> void:
	var tw := create_tween()
	tw.tween_property(sv, "position", LevelData.HATCH_POS + Vector2(0, 8), 0.28).set_trans(Tween.TRANS_QUAD).set_ease(Tween.EASE_IN)
	tw.tween_callback(func():
		Sfx.play("jump", -6.0, randf_range(0.9, 1.15))
		Fx.puff(world, LevelData.HATCH_POS, 8, 45.0, 0.22)
		Fx.burst(world, LevelData.HATCH_POS + Vector2(0, -8), Color(0.6, 1.0, 0.7), 12, 100.0, 0.5, 0.1)
	)
	tw.tween_property(sv, "scale", Vector2(0.4, 0.4), 0.25)
	tw.parallel().tween_property(sv, "modulate:a", 0.0, 0.25)


func _win() -> void:
	state = State.WIN
	Sfx.stop_all()
	Sfx.play("win", -2.0)
	create_tween().tween_property(self, "fx_cold", 0.0, 1.5)
	create_tween().tween_property(self, "fx_frost", 0.0, 1.5)
	create_tween().tween_property(self, "frost_boost", 0.0, 0.5)
	create_tween().tween_property(self, "fx_alarm", 0.0, 0.5)
	fx_alarm = 0.0
	weather.set_outside(false)
	for c in [Color(1.0, 0.8, 0.2), Color(0.4, 0.9, 1.0), Color(1.0, 0.4, 0.6), Color(0.5, 1.0, 0.5)]:
		_confetti(c)
	_show_end("HAYATTA KALDINIZ!", "Sığınağa %d/%d eşya ve %d/%d kişiyle ulaştın.\nKalan süre: %.1f sn\n\nDünya donarken hepiniz sıcacık güvendesiniz." % [collected, ITEM_COUNT, rescued_n, SURVIVOR_COUNT, time_left], Color(0.5, 1.0, 0.6))


func _confetti(col: Color) -> void:
	var p := CPUParticles2D.new()
	p.amount = 60
	p.lifetime = 3.5
	p.emission_shape = CPUParticles2D.EMISSION_SHAPE_RECTANGLE
	p.emission_rect_extents = Vector2(VIEW.x * 0.5, 4)
	p.position = Vector2(VIEW.x * 0.5, -10)
	p.direction = Vector2(0, 1)
	p.spread = 25.0
	p.gravity = Vector2(0, 160)
	p.initial_velocity_min = 80.0
	p.initial_velocity_max = 200.0
	p.angular_velocity_min = -300.0
	p.angular_velocity_max = 300.0
	p.scale_amount_min = 0.1
	p.scale_amount_max = 0.22
	p.texture = Fx.glow_tex()
	p.color = col
	hud.add_child(p)
	p.emitting = true


func _lose() -> void:
	if ending:
		return
	ending = true
	state = State.LOSE
	player.controllable = false
	arrow.visible = false
	edge.enabled = false
	if dialogue.active:
		dialogue.active = false
		dialogue.visible = false
	Sfx.stop_all()
	Sfx.play("lose", 0.0)
	Sfx.play("crack", -2.0)
	shake_kick = 30.0
	fx_alarm = 0.0
	player.crouch_mode = true
	player.breath.emitting = true
	for sv in followers:
		(sv as Survivor).freeze()
	for s in survivors:
		if not (s as Survivor).rescued:
			(s as Survivor).freeze()
	fx_flash = 1.0
	var tw := create_tween()
	tw.tween_property(self, "fx_flash", 0.0, 0.6)
	tw.set_parallel(true)
	tw.tween_property(self, "fx_frost", 2.0, 2.6).set_trans(Tween.TRANS_QUAD).set_ease(Tween.EASE_IN)
	tw.tween_property(self, "fx_cold", 1.0, 1.5)
	tw.tween_property(player.body, "modulate", Color(0.6, 0.85, 1.4), 2.0)
	tw.chain().tween_callback(func():
		Sfx.play("crack", -4.0)
		var why := "Eşyalar: %d/%d" % [collected, ITEM_COUNT]
		if phase >= 2:
			why += "   Kurtarılanlar: %d/%d" % [rescued_n, SURVIVOR_COUNT]
		_show_end("DONDUN...", "2 dakika doldu, sığınağa varamadın.\n" + why, Color(0.55, 0.8, 1.0))
	)


func _show_end(title: String, sub: String, col: Color) -> void:
	var dim := ColorRect.new()
	dim.color = Color(0, 0, 0, 0.0)
	dim.set_anchors_preset(Control.PRESET_FULL_RECT)
	dim.mouse_filter = Control.MOUSE_FILTER_IGNORE
	hud.add_child(dim)
	hud.move_child(dim, 0)
	create_tween().tween_property(dim, "color:a", 0.45, 0.8)
	set_big(title, col)
	big_label.scale = Vector2(2.5, 2.5)
	var tw := create_tween()
	tw.set_parallel(true)
	tw.tween_property(big_label, "scale", Vector2.ONE, 0.5).set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_OUT)
	tw.tween_property(big_label, "modulate:a", 1.0, 0.3)
	sub_label.text = sub + "\n\n[R] veya [Enter]: Tekrar oyna"
	sub_label.add_theme_font_size_override("font_size", 28)
	create_tween().tween_property(sub_label, "modulate:a", 1.0, 0.8).set_delay(0.4)


# ====================================================================== YARDIMCILAR
func set_big(txt: String, col: Color) -> void:
	big_label.text = txt
	big_label.add_theme_color_override("font_color", col)


func show_msg(txt: String, col: Color, dur: float) -> void:
	msg_label.text = txt
	msg_label.add_theme_color_override("font_color", col)
	msg_label.modulate.a = 1.0
	var tw := create_tween()
	tw.tween_interval(dur)
	tw.tween_property(msg_label, "modulate:a", 0.0, 0.5)


func _unhandled_input(event: InputEvent) -> void:
	var ke := event as InputEventKey
	if ke != null and ke.pressed and not ke.echo:
		var k: int = ke.keycode
		if k == KEY_R:
			_restart()
		elif k == KEY_ESCAPE:
			Sfx.stop_all()
			get_tree().change_scene_to_file("res://scenes/Title.tscn")
		elif state == State.INTRO and (k == KEY_SPACE or k == KEY_ENTER):
			skip_intro = true
			_finish_intro()
		elif state == State.DIALOGUE and (k == KEY_SPACE or k == KEY_ENTER):
			dialogue.advance()
		elif (state == State.WIN or state == State.LOSE) and (k == KEY_ENTER or k == KEY_SPACE):
			_restart()


func _restart() -> void:
	Sfx.stop_all()
	get_tree().reload_current_scene()
