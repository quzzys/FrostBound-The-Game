class_name TVScreen
extends Control
# Tam ekran "SON DAKIKA" haber yayini: kayan dunya, yorunge, buz, daktilo yazisi, ticker.

var t: float = 0.0
var shift: float = 0.0      # dunyanin yorungeden kayma miktari 0..1
var ice: float = 0.0        # dunyanin donmasi 0..1
var alert: float = 0.0      # kirmizi alarm 0..1
var typed: float = 0.0      # gorunen harf sayisi
var caption: String = ""
var ticker_x: float = 0.0

const TICKER := "DÜNYA YÖRÜNGESİNDEN SAPTI   •   2 DAKİKA İÇİNDE KÜRESEL BUZ ÇAĞI BAŞLIYOR   •   HERKES EN YAKIN SIĞINAĞA GİTSİN   •   UZAY AJANSI ACİL DURUM YAYINI   •   "


func _process(delta: float) -> void:
	t += delta
	ticker_x -= delta * 150.0
	queue_redraw()


func _draw() -> void:
	var W := size.x
	var H := size.y
	var font := ThemeDB.fallback_font
	var sc := Rect2(36, 30, W - 72, H - 60)

	# stüdyo arka planı (dikey gradyan)
	for i in range(18):
		var k := float(i) / 17.0
		draw_rect(Rect2(sc.position.x, sc.position.y + i * sc.size.y / 18.0, sc.size.x, sc.size.y / 18.0 + 1.0),
			Color(0.04 + 0.05 * k, 0.07 + 0.1 * k, 0.17 + 0.2 * k))
	# ızgara
	for gx in range(0, 24):
		draw_line(Vector2(sc.position.x + gx * 52.0, sc.position.y), Vector2(sc.position.x + gx * 52.0, sc.end.y), Color(0.3, 0.5, 0.9, 0.07), 1.0)
	for gy in range(0, 14):
		draw_line(Vector2(sc.position.x, sc.position.y + gy * 50.0), Vector2(sc.end.x, sc.position.y + gy * 50.0), Color(0.3, 0.5, 0.9, 0.07), 1.0)

	# ---- Güneş (sol)
	var sun := Vector2(70, 290)
	for r in range(6):
		draw_circle(sun, 120.0 - r * 14.0, Color(1.0, 0.7 - r * 0.05, 0.1, 0.07 + r * 0.03))
	draw_circle(sun, 62.0, Color(1.0, 0.85, 0.3))

	# ---- yörünge elipsleri
	var oc := Vector2(310, 292)
	var rx := 215.0
	var ry := 125.0
	var pts := PackedVector2Array()
	for i in range(65):
		var a := TAU * float(i) / 64.0
		pts.append(oc + Vector2(cos(a) * rx, sin(a) * ry))
	draw_polyline(pts, Color(0.5, 0.8, 1.0, 0.45), 2.0)
	# yeni (sapma) yörünge: kırmızı, gittikçe uzayan
	var pts2 := PackedVector2Array()
	var cnt := int(64.0 * clampf(shift * 1.2, 0.0, 1.0))
	for i in range(cnt + 1):
		var a2 := -0.6 + TAU * 0.5 * float(i) / 64.0 * 0.0 - float(i) * 0.03
		var p0 := oc + Vector2(cos(-0.6) * rx, sin(-0.6) * ry)
		pts2.append(p0 + Vector2(float(i) * 3.6, -float(i) * 1.5 + sin(float(i) * 0.1) * 6.0))
	if pts2.size() >= 2:
		draw_polyline(pts2, Color(1.0, 0.25, 0.2, 0.9), 3.0)

	# ---- Dünya
	var base := oc + Vector2(cos(-0.6) * rx, sin(-0.6) * ry)
	var ep := base + Vector2(shift * 230.0, -shift * 95.0)
	var er := 48.0 - shift * 10.0
	for r in range(4):
		draw_circle(ep, er + 14.0 - r * 3.5, Color(0.4, 0.7, 1.0, 0.07 + r * 0.03))
	draw_circle(ep, er, Color(0.1, 0.35, 0.8))
	draw_colored_polygon(PackedVector2Array([ep + Vector2(-30, -10), ep + Vector2(-14, -28), ep + Vector2(4, -14), ep + Vector2(-6, 6), ep + Vector2(-24, 12)]), Color(0.2, 0.65, 0.3))
	draw_colored_polygon(PackedVector2Array([ep + Vector2(10, 4), ep + Vector2(28, -4), ep + Vector2(32, 18), ep + Vector2(16, 30), ep + Vector2(6, 18)]), Color(0.25, 0.6, 0.28))
	if ice > 0.0:
		draw_circle(ep, er, Color(0.85, 0.95, 1.0, ice * 0.85))
		for i in range(7):
			var ang := float(i) * 0.9 + 0.3
			draw_line(ep, ep + Vector2(cos(ang), sin(ang)) * er * ice, Color(1, 1, 1, 0.9), 2.0)
	# uyarı çemberi
	if shift > 0.05:
		var pr := (0.5 + 0.5 * sin(t * 6.0))
		draw_arc(ep, er + 16.0 + pr * 10.0, 0.0, TAU, 40, Color(1.0, 0.2, 0.15, 0.8 - pr * 0.5), 3.0)

	# ---- Sunucu (sağ)
	var ax := 1000.0
	draw_rect(Rect2(ax - 120, 520 - 150, 240, 150), Color(0.06, 0.08, 0.16))
	draw_colored_polygon(PackedVector2Array([Vector2(ax - 100, 370), Vector2(ax + 100, 370), Vector2(ax + 130, 520), Vector2(ax - 130, 520)]), Color(0.1, 0.13, 0.28))
	draw_colored_polygon(PackedVector2Array([Vector2(ax - 22, 372), Vector2(ax + 22, 372), Vector2(ax, 430)]), Color(0.93, 0.93, 0.96))
	draw_colored_polygon(PackedVector2Array([Vector2(ax - 6, 385), Vector2(ax + 6, 385), Vector2(ax + 9, 440), Vector2(ax, 456), Vector2(ax - 9, 440)]), Color(0.75, 0.1, 0.12))
	draw_rect(Rect2(ax - 14, 346, 28, 28), Color(0.85, 0.65, 0.52))
	draw_circle(Vector2(ax, 318), 40.0, Color(0.9, 0.7, 0.56))
	draw_arc(Vector2(ax, 312), 42.0, PI * 1.02, PI * 1.98, 20, Color(0.15, 0.1, 0.08), 12.0)
	# yüz (korku ifadesi)
	var blink := 1.0 if fmod(t, 3.0) > 0.15 else 0.1
	draw_circle(Vector2(ax - 14, 316), 6.0 * blink + 1.0, Color.WHITE)
	draw_circle(Vector2(ax + 14, 316), 6.0 * blink + 1.0, Color.WHITE)
	draw_circle(Vector2(ax - 14, 316), 2.5, Color(0.05, 0.05, 0.05))
	draw_circle(Vector2(ax + 14, 316), 2.5, Color(0.05, 0.05, 0.05))
	var mouth := 4.0 + absf(sin(t * 11.0)) * 8.0 * (1.0 if typed < float(caption.length()) else 0.0)
	draw_circle(Vector2(ax, 338), mouth, Color(0.3, 0.05, 0.07))
	# masa
	draw_rect(Rect2(ax - 190, 505, 380, 26), Color(0.07, 0.07, 0.1))
	draw_rect(Rect2(ax - 190, 505, 380, 4), Color(0.4, 0.7, 1.0, 0.6))

	# ---- üst bilgi çubuğu
	var live := fmod(t, 1.0) < 0.6
	if live:
		draw_circle(Vector2(sc.position.x + 34, sc.position.y + 34), 9.0, Color(1.0, 0.1, 0.1))
	draw_string(font, Vector2(sc.position.x + 52, sc.position.y + 42), "CANLI", HORIZONTAL_ALIGNMENT_LEFT, -1.0, 26, Color.WHITE)
	draw_string(font, Vector2(sc.end.x - 520, sc.position.y + 42), "UZAY AJANSI  •  ACİL YAYIN", HORIZONTAL_ALIGNMENT_RIGHT, 500.0, 24, Color(0.8, 0.9, 1.0))

	# ---- alt üçlü: SON DAKİKA etiketi + altyazı
	var lt := Rect2(sc.position.x + 20, 520, sc.size.x - 40, 76)
	draw_rect(lt, Color(0.95, 0.95, 1.0))
	var tag_col := Color(0.85, 0.05, 0.08) if fmod(t, 0.8) < 0.5 else Color(0.55, 0.03, 0.05)
	draw_rect(Rect2(lt.position.x, lt.position.y - 40, 270, 40), tag_col)
	draw_string(font, Vector2(lt.position.x + 14, lt.position.y - 9), "SON DAKİKA!", HORIZONTAL_ALIGNMENT_LEFT, -1.0, 32, Color.WHITE)
	var shown := caption.substr(0, clampi(int(typed), 0, caption.length()))
	draw_string(font, Vector2(lt.position.x + 20, lt.position.y + 50), shown, HORIZONTAL_ALIGNMENT_LEFT, lt.size.x - 40.0, 38, Color(0.05, 0.05, 0.12))
	if int(t * 2.0) % 2 == 0 and typed < float(caption.length()):
		var cw := font.get_string_size(shown, HORIZONTAL_ALIGNMENT_LEFT, -1.0, 38).x
		draw_rect(Rect2(lt.position.x + 22 + cw, lt.position.y + 18, 4, 38), Color(0.05, 0.05, 0.12))

	# ---- ticker
	var tr := Rect2(sc.position.x, sc.end.y - 38, sc.size.x, 38)
	draw_rect(tr, Color(0.55, 0.04, 0.07))
	var tw := font.get_string_size(TICKER, HORIZONTAL_ALIGNMENT_LEFT, -1.0, 24).x
	var x0 := fmod(ticker_x, tw)
	for i in range(4):
		draw_string(font, Vector2(sc.position.x + x0 + i * tw, tr.position.y + 28), TICKER, HORIZONTAL_ALIGNMENT_LEFT, -1.0, 24, Color.WHITE)

	# ---- alarm kırmızı bindirme
	if alert > 0.0:
		draw_rect(sc, Color(1.0, 0.0, 0.0, alert * 0.3 * (0.5 + 0.5 * sin(t * 14.0))))

	# ---- TV çerçevesi (içeriği kırpar)
	var bz := Color(0.015, 0.015, 0.02)
	draw_rect(Rect2(0, 0, W, sc.position.y), bz)
	draw_rect(Rect2(0, sc.end.y, W, H - sc.end.y), bz)
	draw_rect(Rect2(0, 0, sc.position.x, H), bz)
	draw_rect(Rect2(sc.end.x, 0, W - sc.end.x, H), bz)
	draw_rect(sc.grow(2.0), Color(0.2, 0.22, 0.26), false, 4.0)
	draw_circle(Vector2(W - 20, H - 15), 5.0, Color(0.2, 1.0, 0.3) if int(t) % 2 == 0 else Color(0.05, 0.3, 0.08))
