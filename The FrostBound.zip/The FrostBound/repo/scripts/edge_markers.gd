class_name EdgeMarkers
extends Control
# Ekran disindaki kurtarilmamis kazazedeleri ekran kenarinda titresen oklarla ve mesafeyle gosterir.

var survivors: Array = []
var camera: Camera2D
var player: Node2D
var enabled: bool = false
var t: float = 0.0


func _ready() -> void:
	set_anchors_preset(Control.PRESET_FULL_RECT)
	mouse_filter = Control.MOUSE_FILTER_IGNORE


func _process(delta: float) -> void:
	t += delta
	queue_redraw()


func _draw() -> void:
	if not enabled or camera == null or player == null:
		return
	var font := ThemeDB.fallback_font
	var vs := Vector2(1280, 720)
	var center := camera.get_screen_center_position()
	var half := vs * 0.5
	for s in survivors:
		var sv: Survivor = s
		if sv.rescued:
			continue
		var rel := (sv.position + Vector2(0, -40) - center) * camera.zoom.x
		if absf(rel.x) < half.x - 40.0 and absf(rel.y) < half.y - 40.0:
			continue
		var dir := rel.normalized()
		# ekran kenarina kirp
		var sc := minf((half.x - 52.0) / maxf(absf(rel.x), 0.001), (half.y - 52.0) / maxf(absf(rel.y), 0.001))
		var p := half + rel * sc
		var pulse := 0.5 + 0.5 * sin(t * 7.0 + float(sv.get_index()))
		var dist := int((sv.position - player.position).length() / 10.0)
		var col := Color(1.0, 0.65 + 0.2 * pulse, 0.2, 0.95)
		var ang := dir.angle()
		var pts := PackedVector2Array([
			p + Vector2(20, 0).rotated(ang), p + Vector2(-10, -13).rotated(ang),
			p + Vector2(-4, 0).rotated(ang), p + Vector2(-10, 13).rotated(ang)])
		draw_circle(p, 24.0 + pulse * 4.0, Color(1.0, 0.5, 0.1, 0.18 + 0.12 * pulse))
		draw_colored_polygon(pts, col)
		var name_txt := "%s  %dm" % [String(Dialogues.DATA[sv.id]["name"]), dist]
		var tp := p - dir * 42.0 - Vector2(60, -5)
		tp.x = clampf(tp.x, 6.0, vs.x - 126.0)
		tp.y = clampf(tp.y, 20.0, vs.y - 8.0)
		draw_string_outline(font, tp, name_txt, HORIZONTAL_ALIGNMENT_CENTER, 120.0, 14, 5, Color(0, 0, 0, 0.9))
		draw_string(font, tp, name_txt, HORIZONTAL_ALIGNMENT_CENTER, 120.0, 14, Color(1.0, 0.92, 0.7))
