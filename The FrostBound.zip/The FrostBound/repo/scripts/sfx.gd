extends Node
# Tum sesler kod ile uretilir (harici ses dosyasi gerekmez).
# Kullanim: Sfx.play("pickup"), Sfx.start_loop("wind", -12.0), Sfx.stop_loop("wind")

const RATE := 22050

var sounds: Dictionary = {}
var pool: Array[AudioStreamPlayer] = []
var loops: Dictionary = {}
var rng := RandomNumberGenerator.new()


func _ready() -> void:
	rng.seed = 424242
	for i in range(16):
		var p := AudioStreamPlayer.new()
		add_child(p)
		pool.append(p)
	_build_all()


# ------------------------------------------------------------------ oynatma
func play(snd: String, vol_db: float = 0.0, pitch: float = 1.0) -> void:
	if not sounds.has(snd):
		return
	var chosen: AudioStreamPlayer = null
	for p in pool:
		if not p.playing:
			chosen = p
			break
	if chosen == null:
		chosen = pool[0]
	chosen.stream = sounds[snd]
	chosen.volume_db = vol_db
	chosen.pitch_scale = pitch
	chosen.play()


func start_loop(snd: String, vol_db: float = 0.0, pitch: float = 1.0) -> void:
	if not sounds.has(snd):
		return
	if loops.has(snd):
		var old: AudioStreamPlayer = loops[snd]
		old.volume_db = vol_db
		old.pitch_scale = pitch
		if not old.playing:
			old.play()
		return
	var p := AudioStreamPlayer.new()
	p.stream = sounds[snd]
	p.volume_db = vol_db
	p.pitch_scale = pitch
	add_child(p)
	p.play()
	loops[snd] = p


func set_loop(snd: String, vol_db: float, pitch: float = 1.0) -> void:
	if loops.has(snd):
		var p: AudioStreamPlayer = loops[snd]
		p.volume_db = vol_db
		p.pitch_scale = pitch


func stop_loop(snd: String) -> void:
	if loops.has(snd):
		var p: AudioStreamPlayer = loops[snd]
		p.stop()
		p.queue_free()
		loops.erase(snd)


func stop_all() -> void:
	for k in loops.keys():
		stop_loop(k)
	for p in pool:
		p.stop()


# ------------------------------------------------------------------ sentez yardimcilari
func _buf(sec: float) -> PackedFloat32Array:
	var a := PackedFloat32Array()
	a.resize(int(sec * RATE))
	return a


func _tone(a: PackedFloat32Array, start: float, dur: float, f0: float, f1: float, vol: float, shape: int = 0, decay: float = 4.0, attack: float = 0.004) -> void:
	var n0 := int(start * RATE)
	var n := int(dur * RATE)
	var ph := 0.0
	for i in range(n):
		var idx := n0 + i
		if idx >= a.size():
			break
		var t := float(i) / float(maxi(n, 1))
		var f := lerpf(f0, f1, t)
		ph += TAU * f / float(RATE)
		var s := 0.0
		if shape == 0:
			s = sin(ph)
		elif shape == 1:
			s = 0.6 if sin(ph) > 0.0 else -0.6
		elif shape == 2:
			s = fmod(ph / TAU, 1.0) * 2.0 - 1.0
		else:
			s = absf(fmod(ph / TAU, 1.0) * 4.0 - 2.0) - 1.0
		var env := exp(-decay * t)
		env *= minf(1.0, float(i) / maxf(attack * RATE, 1.0))
		a[idx] += s * vol * env


func _noise(a: PackedFloat32Array, start: float, dur: float, vol: float, decay: float, lp: float, hp: bool = false) -> void:
	var n0 := int(start * RATE)
	var n := int(dur * RATE)
	var y := 0.0
	for i in range(n):
		var idx := n0 + i
		if idx >= a.size():
			break
		var t := float(i) / float(maxi(n, 1))
		var x := rng.randf_range(-1.0, 1.0)
		y += lp * (x - y)
		var s := y
		if hp:
			s = x - y
		a[idx] += s * vol * exp(-decay * t)


func _make(a: PackedFloat32Array, loop: bool = false, fade: bool = true) -> AudioStreamWAV:
	var n := a.size()
	if fade:
		var f := mini(int(0.006 * RATE), n / 2)
		for i in range(f):
			var k := float(i) / float(f)
			a[i] *= k
			a[n - 1 - i] *= k
	var bytes := PackedByteArray()
	bytes.resize(n * 2)
	for i in range(n):
		var v := int(clampf(a[i], -1.0, 1.0) * 32000.0)
		bytes.encode_s16(i * 2, v)
	var s := AudioStreamWAV.new()
	s.format = AudioStreamWAV.FORMAT_16_BITS
	s.mix_rate = RATE
	s.stereo = false
	s.data = bytes
	if loop:
		s.loop_mode = AudioStreamWAV.LOOP_FORWARD
		s.loop_begin = 0
		s.loop_end = n
	return s


# ------------------------------------------------------------------ butun sesler
func _build_all() -> void:
	# esya alma: iki yukselen "ting"
	var a := _buf(0.4)
	_tone(a, 0.0, 0.14, 660.0, 990.0, 0.45, 0, 6.0)
	_tone(a, 0.07, 0.3, 990.0, 1480.0, 0.4, 0, 5.0)
	_tone(a, 0.07, 0.3, 1980.0, 2960.0, 0.12, 0, 7.0)
	sounds["pickup"] = _make(a)

	# esyanin envantere varmasi
	a = _buf(0.3)
	_tone(a, 0.0, 0.1, 520.0, 520.0, 0.35, 3, 7.0)
	_tone(a, 0.08, 0.2, 780.0, 780.0, 0.35, 3, 6.0)
	sounds["slot"] = _make(a)

	# ayak sesi (tahta)
	a = _buf(0.09)
	_noise(a, 0.0, 0.08, 0.7, 14.0, 0.14)
	_tone(a, 0.0, 0.08, 120.0, 60.0, 0.5, 0, 14.0)
	sounds["step"] = _make(a)

	# tik
	a = _buf(0.05)
	_tone(a, 0.0, 0.04, 1900.0, 1700.0, 0.5, 1, 30.0, 0.001)
	sounds["tick"] = _make(a)

	# kalp atisi
	a = _buf(0.5)
	_tone(a, 0.0, 0.16, 65.0, 38.0, 1.0, 0, 9.0)
	_tone(a, 0.2, 0.18, 58.0, 34.0, 0.8, 0, 9.0)
	sounds["beat"] = _make(a)

	# acil durum sireni (EAS iki ton)
	a = _buf(1.4)
	_tone(a, 0.0, 1.4, 853.0, 853.0, 0.3, 0, 0.0)
	_tone(a, 0.0, 1.4, 960.0, 960.0, 0.3, 0, 0.0)
	sounds["eas"] = _make(a)

	# haber jingle'i
	a = _buf(1.2)
	var notes := [392.0, 523.0, 659.0, 784.0, 659.0, 784.0]
	var times := [0.0, 0.13, 0.26, 0.39, 0.6, 0.73]
	for i in range(notes.size()):
		_tone(a, times[i], 0.35, notes[i], notes[i], 0.3, 2, 4.0)
		_tone(a, times[i], 0.35, notes[i] * 2.0, notes[i] * 2.0, 0.1, 0, 5.0)
	sounds["jingle"] = _make(a)

	# daktilo harfi
	a = _buf(0.03)
	_tone(a, 0.0, 0.025, 1300.0, 1100.0, 0.25, 1, 30.0, 0.001)
	sounds["type"] = _make(a)

	# parazit (loop)
	a = _buf(1.0)
	_noise(a, 0.0, 1.0, 0.5, 0.0, 0.85)
	sounds["static"] = _make(a, true, false)

	# ruzgar (loop, 3 sn = 1 tam LFO dongusu)
	a = _buf(3.0)
	var y := 0.0
	for i in range(a.size()):
		var t := float(i) / float(RATE)
		y += 0.05 * (rng.randf_range(-1.0, 1.0) - y)
		a[i] = y * (0.7 + 0.5 * sin(TAU * t / 3.0)) * 1.6
	sounds["wind"] = _make(a, true, false)

	# deprem / gurultu
	a = _buf(3.2)
	var ylp := 0.0
	for i in range(a.size()):
		var t := float(i) / float(RATE)
		var env := minf(t / 0.4, 1.0) * clampf((3.2 - t) / 1.0, 0.0, 1.0)
		ylp += 0.03 * (rng.randf_range(-1.0, 1.0) - ylp)
		var wob := 0.6 + 0.4 * sin(TAU * 9.0 * t)
		a[i] = (ylp * 2.2 + sin(TAU * 38.0 * t) * 0.5 + sin(TAU * 47.0 * t) * 0.35) * env * wob
	sounds["rumble"] = _make(a)

	# deprem aralik (loop, 2 sn)
	a = _buf(2.0)
	var yl := 0.0
	for i in range(a.size()):
		var t := float(i) / float(RATE)
		yl += 0.03 * (rng.randf_range(-1.0, 1.0) - yl)
		a[i] = (yl * 2.0 + sin(TAU * 38.0 * t) * 0.45 + sin(TAU * 47.0 * t) * 0.3) * (0.7 + 0.3 * sin(TAU * 8.0 * t))
	sounds["rumble_l"] = _make(a, true, false)

	# buz catlamasi
	a = _buf(1.2)
	for k in range(7):
		_noise(a, rng.randf_range(0.0, 0.8), 0.12, 0.7, 6.0, 0.7, true)
		_tone(a, rng.randf_range(0.0, 0.8), 0.1, rng.randf_range(2500.0, 4200.0), 1800.0, 0.2, 1, 12.0, 0.001)
	sounds["crack"] = _make(a)

	# siginak kapagi: hidrolik tislama + gong
	a = _buf(1.6)
	_noise(a, 0.0, 1.2, 0.5, 2.5, 0.55, true)
	_tone(a, 0.05, 0.5, 130.0, 55.0, 0.8, 0, 6.0)
	_tone(a, 0.55, 0.9, 90.0, 70.0, 0.5, 0, 4.0)
	_noise(a, 0.55, 0.15, 0.5, 10.0, 0.2)
	sounds["hatch_open"] = _make(a)

	# kapak kapanisi
	a = _buf(0.9)
	_tone(a, 0.0, 0.5, 100.0, 40.0, 1.0, 0, 6.0)
	_noise(a, 0.0, 0.25, 0.8, 8.0, 0.25)
	_noise(a, 0.0, 0.7, 0.3, 4.0, 0.5, true)
	sounds["hatch_close"] = _make(a)

	# kilitli / hata
	a = _buf(0.35)
	_tone(a, 0.0, 0.14, 160.0, 150.0, 0.4, 1, 3.0)
	_tone(a, 0.18, 0.16, 140.0, 120.0, 0.4, 1, 3.0)
	sounds["denied"] = _make(a)

	# ziplama / ucus
	a = _buf(0.35)
	for i in range(a.size()):
		var t := float(i) / float(a.size())
		a[i] = rng.randf_range(-1.0, 1.0) * sin(PI * t) * 0.18 * (0.4 + t)
	_tone(a, 0.0, 0.3, 300.0, 1200.0, 0.15, 0, 3.0)
	sounds["whoosh"] = _make(a)

	# kazanma
	a = _buf(2.2)
	var win_notes := [523.0, 659.0, 784.0, 1047.0, 784.0, 1047.0, 1319.0]
	var win_times := [0.0, 0.15, 0.3, 0.45, 0.8, 0.95, 1.1]
	for i in range(win_notes.size()):
		_tone(a, win_times[i], 0.8, win_notes[i], win_notes[i], 0.28, 3, 3.5)
		_tone(a, win_times[i], 0.8, win_notes[i] * 2.0, win_notes[i] * 2.0, 0.08, 0, 4.0)
	sounds["win"] = _make(a)

	# kaybetme: dusen ton + buz + boom
	a = _buf(3.0)
	_tone(a, 0.0, 2.2, 440.0, 55.0, 0.5, 2, 1.8)
	_tone(a, 0.0, 1.0, 70.0, 28.0, 1.0, 0, 3.0)
	for k in range(6):
		_noise(a, 0.1 + k * 0.18, 0.15, 0.6, 7.0, 0.6, true)
	_noise(a, 0.0, 2.6, 0.35, 1.5, 0.08)
	sounds["lose"] = _make(a)

	# gerilim muzigi: drone (loop, 4 sn)
	a = _buf(4.0)
	for i in range(a.size()):
		var t := float(i) / float(RATE)
		var trem := 0.75 + 0.25 * sin(TAU * 0.25 * t)
		var v := 0.20 * sin(TAU * 55.0 * t) + 0.14 * sin(TAU * 55.5 * t)
		v += 0.10 * sin(TAU * 82.5 * t) + 0.06 * sin(TAU * 110.0 * t)
		a[i] = v * trem
	sounds["drone"] = _make(a, true, false)

	# aksiyon muzigi: 2 sn'lik arpej + davul (loop)
	a = _buf(2.0)
	var arp := [110.0, 164.8, 220.0, 261.6, 220.0, 164.8, 196.0, 146.8]
	for i in range(arp.size()):
		_tone(a, i * 0.25, 0.25, arp[i], arp[i], 0.22, 3, 5.0)
		_tone(a, i * 0.25, 0.25, arp[i] * 2.0, arp[i] * 2.0, 0.07, 1, 6.0)
	for b in range(4):
		_tone(a, b * 0.5, 0.18, 110.0, 42.0, 0.7, 0, 10.0)
	_noise(a, 0.5, 0.12, 0.35, 9.0, 0.5, true)
	_noise(a, 1.5, 0.12, 0.35, 9.0, 0.5, true)
	for h in range(8):
		_noise(a, h * 0.25 + 0.125, 0.04, 0.14, 12.0, 0.8, true)
	sounds["action"] = _make(a, true, false)

	# ================= YENI SESLER (Frostbound) =================
	# "Yardim!" cigligi: iki heceli, formantli insan sesi benzeri (kazazedeler)
	a = _buf(1.15)
	var ph := 0.0
	for i in range(a.size()):
		var t := float(i) / float(RATE)
		var syl := 0.0
		if t < 0.45:
			syl = sin(PI * t / 0.45)
		elif t > 0.5 and t < 1.1:
			syl = sin(PI * (t - 0.5) / 0.6)
		var f0 := 330.0 + 90.0 * sin(PI * clampf(t / 1.1, 0.0, 1.0)) + 9.0 * sin(TAU * 6.0 * t)
		ph += TAU * f0 / float(RATE)
		var f1 := 850.0 if t < 0.45 else 520.0
		var v := 0.0
		for k in range(1, 9):
			var fk := f0 * float(k)
			var amp := exp(-pow((fk - f1) / 420.0, 2.0)) + 0.55 * exp(-pow((fk - 1700.0) / 600.0, 2.0))
			v += amp * sin(ph * float(k)) / float(k) * 1.6
		a[i] = v * syl * 0.34
	sounds["cry"] = _make(a)

	# diyalog "konusma" tiki
	a = _buf(0.06)
	_tone(a, 0.0, 0.05, 240.0, 210.0, 0.4, 1, 18.0, 0.002)
	_tone(a, 0.0, 0.05, 480.0, 420.0, 0.12, 0, 18.0, 0.002)
	sounds["blip"] = _make(a)

	# ana kapi: gicirdama + ruzgar
	a = _buf(1.5)
	_tone(a, 0.0, 0.9, 120.0, 210.0, 0.28, 2, 1.6)
	_tone(a, 0.1, 0.8, 135.0, 250.0, 0.18, 2, 1.8)
	_noise(a, 0.3, 1.2, 0.5, 1.4, 0.07)
	_tone(a, 0.9, 0.3, 90.0, 55.0, 0.5, 0, 8.0)
	sounds["door_open"] = _make(a)

	# ruzgar patlamasi (kapi acilinca / buz dalgasi)
	a = _buf(1.8)
	var yg := 0.0
	for i in range(a.size()):
		var t := float(i) / float(RATE)
		yg += 0.09 * (rng.randf_range(-1.0, 1.0) - yg)
		a[i] = yg * sin(PI * clampf(t / 1.8, 0.0, 1.0)) * 2.4
	sounds["gust"] = _make(a)

	# buzun inlemesi (cok alcak kayan ton + catirdama)
	a = _buf(2.4)
	_tone(a, 0.0, 2.2, 95.0, 38.0, 0.7, 2, 1.1, 0.2)
	_tone(a, 0.0, 2.2, 101.0, 41.0, 0.5, 0, 1.1, 0.2)
	for k in range(9):
		_noise(a, rng.randf_range(0.2, 2.0), 0.09, 0.6, 7.0, 0.8, true)
	sounds["ice_groan"] = _make(a)

	# siren (son saniyeler, dongu 1.6 sn)
	a = _buf(1.6)
	for i in range(a.size()):
		var t := float(i) / float(RATE)
		var f := 620.0 + 380.0 * (0.5 + 0.5 * sin(TAU * t / 1.6 - PI * 0.5))
		a[i] = sin(TAU * f * t) * 0.35 + sin(TAU * f * 2.0 * t) * 0.08
	sounds["siren"] = _make(a, true, false)

	# kazazede kurtarildi: parlak yukselen arpej
	a = _buf(0.9)
	var rn := [523.0, 659.0, 784.0, 1047.0, 1319.0]
	for i in range(rn.size()):
		_tone(a, i * 0.07, 0.5, rn[i], rn[i], 0.28, 3, 4.5)
		_tone(a, i * 0.07, 0.5, rn[i] * 2.0, rn[i] * 2.0, 0.09, 0, 6.0)
	sounds["rescue"] = _make(a)

	# karda adim (gicirti)
	a = _buf(0.12)
	_noise(a, 0.0, 0.11, 0.5, 9.0, 0.35, true)
	_noise(a, 0.0, 0.11, 0.35, 7.0, 0.15)
	sounds["snowstep"] = _make(a)

	# faz gecisi vurusu: dusuk boom + uyumsuz ton
	a = _buf(2.0)
	_tone(a, 0.0, 1.2, 80.0, 30.0, 1.0, 0, 3.0)
	_tone(a, 0.0, 1.8, 311.0, 300.0, 0.18, 2, 2.0)
	_tone(a, 0.0, 1.8, 330.0, 320.0, 0.18, 2, 2.0)
	_noise(a, 0.0, 0.6, 0.5, 4.0, 0.2)
	sounds["sting"] = _make(a)

	# sigmaya inis: tok vurus + ziplama
	a = _buf(0.7)
	_tone(a, 0.0, 0.25, 160.0, 60.0, 0.9, 0, 9.0)
	_noise(a, 0.0, 0.3, 0.5, 6.0, 0.3)
	sounds["jump"] = _make(a)

	# yardim cagrisi sonrasi uzaktan ruzgar uluması (kazazede yakinligi icin)
	a = _buf(1.0)
	_tone(a, 0.0, 0.9, 420.0, 300.0, 0.15, 0, 2.0, 0.05)
	sounds["whine"] = _make(a)

	# ic kapi acilis: kisa gicirti + tokmak
	a = _buf(0.55)
	_tone(a, 0.0, 0.4, 150.0, 230.0, 0.22, 2, 3.0, 0.02)
	_tone(a, 0.05, 0.35, 310.0, 420.0, 0.07, 1, 4.0, 0.02)
	_noise(a, 0.0, 0.08, 0.35, 12.0, 0.3)
	sounds["door_o"] = _make(a)

	# ic kapi kapanis: tok vurus
	a = _buf(0.4)
	_tone(a, 0.0, 0.18, 120.0, 55.0, 0.8, 0, 12.0)
	_noise(a, 0.0, 0.1, 0.6, 16.0, 0.25)
	_tone(a, 0.12, 0.2, 200.0, 170.0, 0.12, 1, 14.0)
	sounds["door_c"] = _make(a)

	# menu: dugme uzerine gelme / tiklama / ac
	a = _buf(0.08)
	_tone(a, 0.0, 0.07, 900.0, 1300.0, 0.25, 0, 20.0, 0.002)
	sounds["ui_hover"] = _make(a)
	a = _buf(0.35)
	_tone(a, 0.0, 0.12, 400.0, 600.0, 0.4, 3, 8.0)
	_tone(a, 0.08, 0.25, 800.0, 1200.0, 0.3, 0, 7.0)
	_noise(a, 0.0, 0.2, 0.25, 9.0, 0.5, true)
	sounds["ui_click"] = _make(a)


func stream(snd: String) -> AudioStream:
	if sounds.has(snd):
		return sounds[snd]
	return null
