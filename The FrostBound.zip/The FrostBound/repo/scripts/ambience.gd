class_name Ambience
extends Node2D
# Evin ici atmosferi: fener/mum/soba isiklari (titreyen), kor kivilcimlari, baca dumani,
# pencere ayazi, televizyon isigi. Zaman ilerledikce isiklar titrer, soner, ev soguyor.

var lights: Array = []        # {node, base, kind, phase, size}
var fires: Array = []         # {glow, parts}
var windows: Array = []
var tv_glow: Sprite2D
var progress: float = 0.0
var blackout_k: float = 0.0   # 0..1 isiklarin ani sonmesi
var t: float = 0.0
var panic: float = 0.0


func _ready() -> void:
	for p in LevelData.LANTERNS:
		_add_light(p + Vector2(0, 6), Color(1.0, 0.72, 0.35), 3.3, 0.5, 0)
	for p in LevelData.CANDLES:
		_add_light(p, Color(1.0, 0.75, 0.4), 1.9, 0.5, 1)
	for p in LevelData.FIRES:
		_add_fire(p)
	for p in LevelData.WINDOWS:
		var w := Sprite2D.new()
		w.texture = Fx.glow_tex()
		w.material = Fx.additive()
		w.position = p
		w.scale = Vector2(1.5, 1.1)
		w.modulate = Color(0.6, 0.8, 1.0, 0.0)
		add_child(w)
		windows.append(w)
	# televizyon isigi
	tv_glow = Sprite2D.new()
	tv_glow.texture = Fx.glow_tex()
	tv_glow.material = Fx.additive()
	tv_glow.position = LevelData.TV_RECT.get_center() + Vector2(0, 40)
	tv_glow.scale = Vector2(3.4, 2.6)
	tv_glow.modulate = Color(0.45, 0.65, 1.0, 0.35)
	add_child(tv_glow)
	# baca dumani
	for p in LevelData.CHIMNEYS:
		var s := CPUParticles2D.new()
		s.amount = 14
		s.lifetime = 3.2
		s.direction = Vector2(0.4, -1)
		s.spread = 18.0
		s.gravity = Vector2(14, -6)
		s.initial_velocity_min = 14.0
		s.initial_velocity_max = 26.0
		s.scale_amount_min = 0.10
		s.scale_amount_max = 0.32
		s.texture = Fx.glow_tex()
		var ramp := Gradient.new()
		ramp.set_color(0, Color(0.75, 0.75, 0.8, 0.0))
		ramp.add_point(0.2, Color(0.75, 0.75, 0.8, 0.28))
		ramp.set_color(ramp.get_point_count() - 1, Color(0.8, 0.85, 0.95, 0.0))
		s.color_ramp = ramp
		s.position = p
		add_child(s)


func _add_light(pos: Vector2, col: Color, size: float, base: float, kind: int) -> void:
	var s := Sprite2D.new()
	s.texture = Fx.glow_tex()
	s.material = Fx.additive()
	s.position = pos
	s.scale = Vector2(size, size * 0.8)
	s.modulate = Color(col.r, col.g, col.b, base)
	add_child(s)
	lights.append({"node": s, "col": col, "base": base, "kind": kind, "phase": randf() * TAU, "size": size})


func _add_fire(pos: Vector2) -> void:
	var g := Sprite2D.new()
	g.texture = Fx.glow_tex()
	g.material = Fx.additive()
	g.position = pos
	g.scale = Vector2(4.2, 3.4)
	g.modulate = Color(1.0, 0.4, 0.12, 0.45)
	add_child(g)
	var p := CPUParticles2D.new()
	p.amount = 12
	p.lifetime = 1.3
	p.direction = Vector2(0, -1)
	p.spread = 35.0
	p.gravity = Vector2(0, -30)
	p.initial_velocity_min = 14.0
	p.initial_velocity_max = 44.0
	p.scale_amount_min = 0.025
	p.scale_amount_max = 0.07
	p.texture = Fx.glow_tex()
	p.material = Fx.additive()
	p.emission_shape = CPUParticles2D.EMISSION_SHAPE_SPHERE
	p.emission_sphere_radius = 12.0
	var ramp := Gradient.new()
	ramp.set_color(0, Color(1.0, 0.9, 0.4, 1.0))
	ramp.add_point(0.5, Color(1.0, 0.45, 0.1, 0.8))
	ramp.set_color(ramp.get_point_count() - 1, Color(0.8, 0.1, 0.0, 0.0))
	p.color_ramp = ramp
	p.position = pos + Vector2(0, -4)
	add_child(p)
	fires.append({"glow": g, "parts": p})


# Ani karanlik (deprem / buz dalgasi): isiklar sonup geri gelir
func blackout(dur: float = 0.45) -> void:
	blackout_k = 1.0
	var tw := create_tween()
	tw.tween_interval(dur * 0.4)
	tw.tween_property(self, "blackout_k", 0.0, dur)


func update_state(prog: float, pan: float) -> void:
	progress = prog
	panic = pan


func _process(delta: float) -> void:
	t += delta
	var heat := 1.0 - progress * 0.78          # ev soguyor: isiklar zayiflar
	var jitter := 0.05 + progress * 0.35 + panic * 0.2
	for L in lights:
		var n: Sprite2D = L["node"]
		var col: Color = L["col"]
		var fl := 0.9 + 0.1 * sin(t * 9.0 + float(L["phase"])) + (randf() - 0.5) * jitter
		# yuksek ilerlemede ara sira kisa sonme
		if progress > 0.5 and sin(t * 1.7 + float(L["phase"]) * 3.0) > 0.985 - progress * 0.04:
			fl *= 0.15
		var e: float = float(L["base"]) * heat * fl * (1.0 - blackout_k)
		n.modulate = Color(col.r, col.g, col.b, clampf(e, 0.0, 1.0))
	for F in fires:
		var g: Sprite2D = F["glow"]
		var pr: CPUParticles2D = F["parts"]
		var ff := 0.8 + 0.2 * sin(t * 13.0) + (randf() - 0.5) * 0.15
		g.modulate = Color(1.0, 0.42, 0.12, clampf(0.5 * heat * ff * (1.0 - blackout_k * 0.4), 0.0, 1.0))
		var gs := 4.2 * (0.7 + 0.3 * heat) * (0.95 + 0.05 * sin(t * 11.0))
		g.scale = Vector2(gs, gs * 0.8)
		pr.speed_scale = 0.6 + 0.6 * heat
	for w in windows:
		var wn: Sprite2D = w
		wn.modulate = Color(0.6, 0.82, 1.0, clampf(0.12 + progress * 0.5, 0.0, 0.7) * (0.85 + 0.15 * sin(t * 3.0)))
	# TV: parazit titremesi
	var tvf := 0.55 + 0.45 * sin(t * 23.0) * sin(t * 7.0)
	tv_glow.modulate = Color(0.45, 0.65, 1.0, 0.18 + 0.2 * tvf * (1.0 - blackout_k))
