extends Node2D
# FROSTBOUND giris ekrani: karli ev manzarasi, kar firtinasi, buzlu logo ve buz temali butonlar.

const VIEW := Vector2(1280, 720)

var t: float = 0.0
var bg: Sprite2D
var weather: Weather
var post_mat: ShaderMaterial
var ui: CanvasLayer
var logo: Control
var menu: VBoxContainer
var howto: Panel
var fade: ColorRect
var buttons: Array = []
var starting: bool = false
var glitch_t: float = 3.0


# ------------------------------------------------------------------ logo (buz sarkitli yazi)
class Logo extends Control:
	var t: float = 0.0
	var icicles: Array = []

	func _ready() -> void:
		var rng := RandomNumberGenerator.new()
		rng.seed = 77
		var x := 0.0
		while x < 1.0:
			icicles.append({"x": x, "len": rng.randf_range(10.0, 46.0), "w": rng.randf_range(5.0, 11.0)})
			x += rng.randf_range(0.012, 0.03)

	func _process(delta: float) -> void:
		t += delta
		queue_redraw()

	func _draw() -> void:
		var font := ThemeDB.fallback_font
		var txt := "FROSTBOUND"
		var fs := 132
		var tw := font.get_string_size(txt, HORIZONTAL_ALIGNMENT_LEFT, -1.0, fs).x
		var x0 := (size.x - tw) * 0.5
		var base := Vector2(x0, 118.0)
		# arkadan buz parlamasi
		for i in range(6):
			draw_circle(Vector2(size.x * 0.5, 80.0), 300.0 - i * 40.0, Color(0.4, 0.7, 1.0, 0.018 + 0.006 * sin(t * 1.5)))
		# golge + koyu kontur
		draw_string(font, base + Vector2(7, 9), txt, HORIZONTAL_ALIGNMENT_LEFT, -1.0, fs, Color(0.0, 0.03, 0.1, 0.8))
		draw_string_outline(font, base, txt, HORIZONTAL_ALIGNMENT_LEFT, -1.0, fs, 14, Color(0.04, 0.12, 0.28, 1.0))
		draw_string_outline(font, base, txt, HORIZONTAL_ALIGNMENT_LEFT, -1.0, fs, 5, Color(0.55, 0.82, 1.0, 1.0))
		# buzlu govde: ust acik, alt koyu iki katman
		draw_string(font, base, txt, HORIZONTAL_ALIGNMENT_LEFT, -1.0, fs, Color(0.72, 0.9, 1.0))
		draw_string(font, base + Vector2(0, 1.5), txt, HORIZONTAL_ALIGNMENT_LEFT, -1.0, fs, Color(0.93, 0.98, 1.0, 0.55))
		# gecen isik parlamasi
		var sx := fmod(t * 260.0, tw + 500.0) - 250.0
		for k in range(8):
			var a := 0.10 - float(k) * 0.011
			draw_rect(Rect2(x0 + sx + k * 6.0, base.y - fs * 0.78, 5.0, fs * 0.86), Color(1, 1, 1, maxf(a, 0.0)))
		# alt yazi
		var sub := "2  D A K İ K A"
		var ss := font.get_string_size(sub, HORIZONTAL_ALIGNMENT_LEFT, -1.0, 30).x
		draw_string_outline(font, Vector2((size.x - ss) * 0.5, 188.0), sub, HORIZONTAL_ALIGNMENT_LEFT, -1.0, 30, 8, Color(0, 0.03, 0.1, 0.95))
		draw_string(font, Vector2((size.x - ss) * 0.5, 188.0), sub, HORIZONTAL_ALIGNMENT_LEFT, -1.0, 30, Color(1.0, 0.55, 0.4))


func _ready() -> void:
	# arka plan: karli ev (harita), yavas kayan kamera
	bg = Sprite2D.new()
	bg.texture = load("res://assets/map.jpg")
	bg.centered = false
	bg.modulate = Color(0.55, 0.68, 0.95)
	add_child(bg)

	weather = Weather.new()
	add_child(weather)
	weather.set_progress(0.65)
	weather.set_outside(true)

	# koyu gradyan perde (alt ve ust)
	var shade := CanvasLayer.new()
	shade.layer = 6
	add_child(shade)
	var g := Gradient.new()
	g.set_color(0, Color(0.01, 0.03, 0.08, 0.55))
	g.add_point(0.45, Color(0.01, 0.03, 0.08, 0.2))
	g.set_color(g.get_point_count() - 1, Color(0.01, 0.03, 0.08, 0.85))
	var gt := GradientTexture2D.new()
	gt.gradient = g
	gt.fill_from = Vector2(0.5, 0.0)
	gt.fill_to = Vector2(0.5, 1.0)
	gt.width = 8
	gt.height = 256
	var tr := TextureRect.new()
	tr.texture = gt
	tr.set_anchors_preset(Control.PRESET_FULL_RECT)
	tr.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	tr.stretch_mode = TextureRect.STRETCH_SCALE
	tr.mouse_filter = Control.MOUSE_FILTER_IGNORE
	shade.add_child(tr)

	# son-isleme: kirac, soguk renk, hafif firtina
	var pl := CanvasLayer.new()
	pl.layer = 7
	add_child(pl)
	var pr := ColorRect.new()
	pr.set_anchors_preset(Control.PRESET_FULL_RECT)
	pr.mouse_filter = Control.MOUSE_FILTER_IGNORE
	post_mat = ShaderMaterial.new()
	post_mat.shader = load("res://shaders/post.gdshader")
	pr.material = post_mat
	pl.add_child(pr)
	post_mat.set_shader_parameter("cold", 0.7)
	post_mat.set_shader_parameter("frost", 0.55)
	post_mat.set_shader_parameter("storm", 0.28)

	_build_ui()

	fade = ColorRect.new()
	fade.color = Color(0, 0, 0, 1)
	fade.set_anchors_preset(Control.PRESET_FULL_RECT)
	fade.mouse_filter = Control.MOUSE_FILTER_IGNORE
	var fl := CanvasLayer.new()
	fl.layer = 30
	add_child(fl)
	fl.add_child(fade)
	create_tween().tween_property(fade, "color:a", 0.0, 1.2)

	Sfx.start_loop("wind", -9.0, 1.05)
	Sfx.start_loop("drone", -17.0)
	if buttons.size() > 0:
		(buttons[0] as Button).grab_focus()


func _build_ui() -> void:
	ui = CanvasLayer.new()
	ui.layer = 10
	add_child(ui)

	logo = Logo.new()
	logo.position = Vector2(0, 70)
	logo.size = Vector2(VIEW.x, 230)
	logo.mouse_filter = Control.MOUSE_FILTER_IGNORE
	ui.add_child(logo)

	menu = VBoxContainer.new()
	menu.position = Vector2(VIEW.x * 0.5 - 190.0, 360.0)
	menu.size = Vector2(380, 280)
	menu.add_theme_constant_override("separation", 16)
	ui.add_child(menu)
	_add_button("OYUNA BAŞLA", _on_start)
	_add_button("NASIL OYNANIR", _on_howto)
	_add_button("ÇIKIŞ", _on_quit)

	var foot := Label.new()
	foot.text = "Yön: WASD / Oklar    Seç: Enter / Fare"
	foot.add_theme_font_size_override("font_size", 15)
	foot.add_theme_color_override("font_color", Color(0.7, 0.82, 1.0, 0.8))
	foot.add_theme_color_override("font_outline_color", Color(0, 0, 0, 0.9))
	foot.add_theme_constant_override("outline_size", 4)
	foot.position = Vector2(0, VIEW.y - 34)
	foot.size = Vector2(VIEW.x, 24)
	foot.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	ui.add_child(foot)

	_build_howto()


func _style(bg: Color, border: Color, bw: int = 2) -> StyleBoxFlat:
	var sb := StyleBoxFlat.new()
	sb.bg_color = bg
	sb.border_color = border
	sb.set_border_width_all(bw)
	sb.set_corner_radius_all(8)
	sb.shadow_color = Color(0.3, 0.6, 1.0, 0.25)
	sb.shadow_size = 8
	sb.content_margin_left = 16
	sb.content_margin_right = 16
	return sb


func _add_button(txt: String, cb: Callable) -> Button:
	var b := Button.new()
	b.text = txt
	b.custom_minimum_size = Vector2(380, 62)
	b.add_theme_font_size_override("font_size", 28)
	b.add_theme_color_override("font_color", Color(0.85, 0.94, 1.0))
	b.add_theme_color_override("font_hover_color", Color(1, 1, 1))
	b.add_theme_color_override("font_focus_color", Color(1, 1, 1))
	b.add_theme_color_override("font_pressed_color", Color(1.0, 0.85, 0.5))
	b.add_theme_color_override("font_outline_color", Color(0, 0.05, 0.15, 0.9))
	b.add_theme_constant_override("outline_size", 5)
	b.add_theme_stylebox_override("normal", _style(Color(0.04, 0.09, 0.17, 0.78), Color(0.4, 0.68, 0.95, 0.75)))
	b.add_theme_stylebox_override("hover", _style(Color(0.1, 0.22, 0.38, 0.92), Color(0.85, 0.95, 1.0, 1.0), 3))
	b.add_theme_stylebox_override("focus", _style(Color(0.1, 0.22, 0.38, 0.92), Color(0.85, 0.95, 1.0, 1.0), 3))
	b.add_theme_stylebox_override("pressed", _style(Color(0.2, 0.15, 0.08, 0.95), Color(1.0, 0.7, 0.3, 1.0), 3))
	b.pivot_offset = Vector2(190, 31)
	b.mouse_entered.connect(_hover.bind(b))
	b.focus_entered.connect(_hover.bind(b))
	b.mouse_exited.connect(_unhover.bind(b))
	b.focus_exited.connect(_unhover.bind(b))
	b.pressed.connect(cb)
	menu.add_child(b)
	buttons.append(b)
	return b


func _hover(b: Button) -> void:
	Sfx.play("ui_hover", -8.0, randf_range(0.95, 1.1))
	create_tween().tween_property(b, "scale", Vector2(1.06, 1.06), 0.12).set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_OUT)
	glitch_t = 0.0


func _unhover(b: Button) -> void:
	create_tween().tween_property(b, "scale", Vector2.ONE, 0.12)


func _build_howto() -> void:
	howto = Panel.new()
	howto.position = Vector2(240, 60)
	howto.size = Vector2(800, 600)
	howto.add_theme_stylebox_override("panel", _style(Color(0.03, 0.06, 0.12, 0.95), Color(0.6, 0.85, 1.0, 0.95), 3))
	howto.visible = false
	ui.add_child(howto)
	var l := Label.new()
	l.text = "NASIL OYNANIR\n\n• Dünya yörüngeden saptı: 2 dakikan var.\n• 1. Aşama: Evdeki 10 eşyayı topla (ana kapı donmuş).\n• 2. Aşama: Dışarıdan yardım sesleri gelir. Beş kişiyi bul,\n   kısa konuşma sonrası seni takip ederler.\n• 3. Aşama: Hepsi seninle olunca sağ üstteki odadaki\n   sığınağa atla!\n\nWASD / Oklar: Yürü     Shift: Koş\nBoşluk / Enter: Diyalog ve haber atla\nR: Yeniden başla     Esc: Menü"
	l.add_theme_font_size_override("font_size", 20)
	l.add_theme_color_override("font_color", Color(0.9, 0.96, 1.0))
	l.add_theme_color_override("font_outline_color", Color(0, 0.03, 0.1, 0.9))
	l.add_theme_constant_override("outline_size", 4)
	l.position = Vector2(34, 26)
	l.size = Vector2(740, 440)
	l.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	howto.add_child(l)
	var back := Button.new()
	back.text = "GERİ"
	back.position = Vector2(300, 510)
	back.size = Vector2(200, 54)
	back.add_theme_font_size_override("font_size", 26)
	back.add_theme_stylebox_override("normal", _style(Color(0.04, 0.09, 0.17, 0.9), Color(0.4, 0.68, 0.95, 0.9)))
	back.add_theme_stylebox_override("hover", _style(Color(0.1, 0.22, 0.38, 0.95), Color(1, 1, 1, 1.0), 3))
	back.add_theme_stylebox_override("focus", _style(Color(0.1, 0.22, 0.38, 0.95), Color(1, 1, 1, 1.0), 3))
	back.pressed.connect(_on_back)
	howto.add_child(back)


func _on_howto() -> void:
	Sfx.play("ui_click", -6.0)
	howto.visible = true
	menu.visible = false
	logo.visible = false
	for c in howto.get_children():
		if c is Button:
			(c as Button).grab_focus()


func _on_back() -> void:
	Sfx.play("ui_click", -6.0)
	howto.visible = false
	menu.visible = true
	logo.visible = true
	(buttons[0] as Button).grab_focus()


func _on_quit() -> void:
	Sfx.play("ui_click", -6.0)
	get_tree().quit()


func _on_start() -> void:
	if starting:
		return
	starting = true
	Sfx.play("ui_click", -3.0)
	Sfx.play("sting", -10.0)
	var tw := create_tween()
	tw.tween_property(fade, "color:a", 1.0, 0.8)
	tw.tween_callback(_go)


func _go() -> void:
	Sfx.stop_all()
	get_tree().change_scene_to_file("res://scenes/Main.tscn")


func _unhandled_input(event: InputEvent) -> void:
	var ke := event as InputEventKey
	if ke != null and ke.pressed and not ke.echo and ke.keycode == KEY_ESCAPE and howto.visible:
		_on_back()


func _process(delta: float) -> void:
	t += delta
	# yavas kamera kaymasi (evin etrafinda)
	bg.position = Vector2(-1000.0 + sin(t * 0.07) * 150.0, -150.0 + sin(t * 0.11) * 50.0)
	# ara sira buz glitch'i
	glitch_t += delta
	var gl := 0.0
	if glitch_t < 0.25:
		gl = 0.5 * (1.0 - glitch_t / 0.25)
	elif randf() < 0.002:
		glitch_t = 0.0
	post_mat.set_shader_parameter("glitch", gl)
	post_mat.set_shader_parameter("storm", 0.22 + 0.08 * sin(t * 0.8) + weather.gust_k * 0.15)
