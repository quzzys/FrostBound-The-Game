class_name Fx
extends RefCounted
# Ortak efekt yardimcilari: isik dokusu, parcacik patlamasi, halka, kar tozu, ayak izi...

static var _glow: Texture2D = null
static var _dot: Texture2D = null
static var _streak: Texture2D = null
static var _flake: Texture2D = null


static func glow_tex() -> Texture2D:
	if _glow == null:
		var g := Gradient.new()
		g.set_color(0, Color(1, 1, 1, 1))
		g.set_color(1, Color(1, 1, 1, 0))
		var t := GradientTexture2D.new()
		t.gradient = g
		t.fill = GradientTexture2D.FILL_RADIAL
		t.fill_from = Vector2(0.5, 0.5)
		t.fill_to = Vector2(0.5, 0.0)
		t.width = 128
		t.height = 128
		_glow = t
	return _glow


# Keskin kenarli kucuk yuvarlak nokta (kar tanesi, kivilcim)
static func dot_tex() -> Texture2D:
	if _dot == null:
		var img := Image.create(16, 16, false, Image.FORMAT_RGBA8)
		for y in range(16):
			for x in range(16):
				var d := Vector2(x - 7.5, y - 7.5).length()
				var a := clampf((7.0 - d) / 2.0, 0.0, 1.0)
				img.set_pixel(x, y, Color(1, 1, 1, a))
		_dot = ImageTexture.create_from_image(img)
	return _dot


# Yatay ruzgar cizgisi (blizzard)
static func streak_tex() -> Texture2D:
	if _streak == null:
		var img := Image.create(64, 4, false, Image.FORMAT_RGBA8)
		for y in range(4):
			for x in range(64):
				var a := (1.0 - absf(float(x) - 40.0) / 40.0)
				a = clampf(a, 0.0, 1.0) * (1.0 - absf(float(y) - 1.5) / 2.2)
				img.set_pixel(x, y, Color(1, 1, 1, clampf(a, 0.0, 1.0)))
		_streak = ImageTexture.create_from_image(img)
	return _streak


# Kar tanesi: kucuk 4 kollu yildiz
static func flake_tex() -> Texture2D:
	if _flake == null:
		var img := Image.create(9, 9, false, Image.FORMAT_RGBA8)
		for i in range(9):
			img.set_pixel(i, 4, Color(1, 1, 1, 0.9))
			img.set_pixel(4, i, Color(1, 1, 1, 0.9))
		img.set_pixel(4, 4, Color(1, 1, 1, 1))
		for k in [1, 2]:
			img.set_pixel(4 - k, 4 - k, Color(1, 1, 1, 0.6))
			img.set_pixel(4 + k, 4 + k, Color(1, 1, 1, 0.6))
			img.set_pixel(4 - k, 4 + k, Color(1, 1, 1, 0.6))
			img.set_pixel(4 + k, 4 - k, Color(1, 1, 1, 0.6))
		_flake = ImageTexture.create_from_image(img)
	return _flake


static func additive() -> CanvasItemMaterial:
	var m := CanvasItemMaterial.new()
	m.blend_mode = CanvasItemMaterial.BLEND_MODE_ADD
	return m


static func _ramp(col: Color, a0: float = 1.0) -> Gradient:
	var ramp := Gradient.new()
	ramp.set_color(0, Color(col.r, col.g, col.b, a0))
	ramp.set_color(1, Color(col.r, col.g, col.b, 0.0))
	return ramp


# Tek seferlik parcacik patlamasi
static func burst(parent: Node, pos: Vector2, col: Color, amount: int = 22, speed: float = 150.0, life: float = 0.7, size: float = 0.12) -> void:
	var p := CPUParticles2D.new()
	p.one_shot = true
	p.amount = amount
	p.lifetime = life
	p.explosiveness = 1.0
	p.direction = Vector2(0, -1)
	p.spread = 180.0
	p.gravity = Vector2(0, 160)
	p.initial_velocity_min = speed * 0.4
	p.initial_velocity_max = speed
	p.scale_amount_min = size * 0.6
	p.scale_amount_max = size
	p.texture = glow_tex()
	p.material = additive()
	p.color_ramp = _ramp(col)
	p.emitting = false
	parent.add_child(p)
	p.position = pos
	p.emitting = true
	p.finished.connect(p.queue_free)


# Beyaz kar tozu bulutu (kosarken / kapi acilirken / dusunce)
static func puff(parent: Node, pos: Vector2, amount: int = 8, speed: float = 40.0, size: float = 0.22, col: Color = Color(0.92, 0.97, 1.0)) -> void:
	var p := CPUParticles2D.new()
	p.one_shot = true
	p.amount = amount
	p.lifetime = 0.7
	p.explosiveness = 0.9
	p.direction = Vector2(0, -1)
	p.spread = 120.0
	p.gravity = Vector2(0, -12)
	p.initial_velocity_min = speed * 0.4
	p.initial_velocity_max = speed
	p.scale_amount_min = size * 0.6
	p.scale_amount_max = size
	p.texture = glow_tex()
	p.color_ramp = _ramp(col, 0.55)
	p.emitting = false
	parent.add_child(p)
	p.position = pos
	p.emitting = true
	p.finished.connect(p.queue_free)


# Genisleyen halka (yardim cagrisi, kurtarma, deprem)
class Ring extends Node2D:
	var t: float = 0.0
	var life: float = 0.9
	var r0: float = 8.0
	var r1: float = 90.0
	var col: Color = Color.WHITE
	var width: float = 3.0

	func _ready() -> void:
		material = Fx.additive()

	func _process(delta: float) -> void:
		t += delta
		if t >= life:
			queue_free()
			return
		queue_redraw()

	func _draw() -> void:
		var k: float = t / life
		var e: float = 1.0 - pow(1.0 - k, 2.2)
		var r: float = lerpf(r0, r1, e)
		var c := Color(col.r, col.g, col.b, col.a * (1.0 - k))
		draw_arc(Vector2.ZERO, r, 0.0, TAU, 40, c, maxf(1.0, width * (1.0 - k * 0.7)))
		draw_arc(Vector2.ZERO, r * 0.82, 0.0, TAU, 32, Color(c.r, c.g, c.b, c.a * 0.4), 1.5)


static func ring(parent: Node, pos: Vector2, col: Color, radius: float = 90.0, dur: float = 0.9, width: float = 3.0) -> void:
	var r := Ring.new()
	r.col = col
	r.r1 = radius
	r.life = dur
	r.width = width
	parent.add_child(r)
	r.position = pos


# Karda ayak izi (zamanla solar)
static func footprint(parent: Node, pos: Vector2, flip: bool) -> void:
	var s := Sprite2D.new()
	s.texture = glow_tex()
	s.position = pos + Vector2(-4.0 if flip else 4.0, 0.0)
	s.scale = Vector2(0.07, 0.11)
	s.modulate = Color(0.25, 0.35, 0.5, 0.5)
	parent.add_child(s)
	var tw := s.create_tween()
	tw.tween_property(s, "modulate:a", 0.0, 5.0)
	tw.tween_callback(s.queue_free)
