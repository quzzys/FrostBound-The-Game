class_name LevelData
extends RefCounted
# Yeni harita (assets/map.jpg, 2576x1093) icin koordinatlar, piksel cinsinden.
# Eski ornekteki veriler baska bir haritaya (1438 px yukseklik) aitti; hepsi yeniden olculdu.
# Carpisma karakterin AYAKLARI (24x8 kutu) ile test edilir.
# Bir nokta: ya yuruyebilir ic mekan (WALK) icindedir ya da evin DISINDADIR (HOUSE disinda).

const MAP_SIZE := Vector2(2576, 1093)
const FEET_W := 26.0
const FEET_H := 12.0

const SPAWN_POS := Vector2(1225, 395)        # oturma odasi, TV'nin onu
const TV_RECT := Rect2(1201, 233, 45, 28)    # televizyon ekrani (cam kisim)
const HATCH_POS := Vector2(1943, 413)        # sag ust oda (depo) - SIGINAK GIRISI
const HATCH_ENTER := Vector2(1943, 440)      # girisin onunde durulacak nokta
const DOOR_POS := Vector2(1215, 835)         # ana kapi
const DOOR_GATE := Rect2(1172, 836, 86, 12)  # esyalar toplanana kadar kapiyi kapatir

# Isik / ates noktalari (ambience.gd kullanir)
const LANTERNS = [Vector2(637, 512), Vector2(833, 512), Vector2(1163, 512), Vector2(1308, 515), Vector2(1622, 515)]
const CANDLES = [Vector2(685, 302), Vector2(1047, 360), Vector2(1442, 633), Vector2(1662, 803)]
const FIRES = [Vector2(753, 350), Vector2(580, 572), Vector2(1588, 722)]
const WINDOWS = [Vector2(886, 517), Vector2(1683, 515), Vector2(1115, 205)]
const CHIMNEYS = [Vector2(757, 262), Vector2(578, 480)]

# Hayatta kalanlar (kazazedeler) - evin DISINDA
const SURVIVORS = {
	"barbaros": Vector2(400, 560),
	"leyla": Vector2(500, 1010),
	"yusuf": Vector2(1620, 300),
	"selahattin": Vector2(2300, 620),
	"zeynep": Vector2(2050, 1010),
}

const WALK = [
	Rect2(548, 556, 1550, 144),   # hol (duvar dibinden 11 px icerde: kafa duvara girmesin)
	Rect2(668, 455, 47, 105),     # yatak odasi kapisi
	Rect2(548, 318, 275, 150),    # yatak odasi
	Rect2(1192, 455, 47, 105),    # oturma odasi kapisi
	Rect2(1030, 312, 370, 158),   # oturma odasi
	Rect2(1895, 345, 95, 215),    # depo (siginak odasi)
	Rect2(866, 690, 36, 100),     # banyo kapisi
	Rect2(660, 765, 255, 140),    # banyo
	Rect2(1090, 695, 265, 145),   # antre
	Rect2(1180, 800, 70, 105),    # ana kapi araligi (disari cikis)
	Rect2(1503, 695, 270, 210),   # mutfak
]

# Evin dis duvarlari dahil kapladigi alan: DISARIDAKI yuruyus bunlarin icine giremez.
const HOUSE = [
	Rect2(522, 240, 318, 240),    # yatak odasi
	Rect2(498, 470, 1625, 246),   # hol
	Rect2(992, 140, 458, 340),    # oturma odasi
	Rect2(1795, 285, 325, 200),   # depo
	Rect2(625, 690, 335, 320),    # banyo + ahsap duvar
	Rect2(1062, 690, 310, 185),   # antre
	Rect2(1462, 690, 345, 315),   # mutfak + ahsap duvar
	Rect2(498, 700, 130, 85),     # hol alt-sol ahsap
	Rect2(1365, 700, 100, 75),    # antre-mutfak arasi ahsap
	Rect2(1805, 700, 320, 100),   # hol alt-sag ahsap
]

# Ic mobilyalar
const OBST = [
	Rect2(565, 295, 95, 135),     # yatak
	Rect2(660, 300, 50, 70),      # komodin
	Rect2(725, 250, 65, 135),     # yatak odasi sobasi
	Rect2(1185, 230, 80, 75),     # tv masasi
	Rect2(1285, 180, 115, 122),   # kitaplik
	Rect2(1110, 250, 80, 55),     # odun sepeti
	Rect2(1025, 360, 78, 112),    # masa + sandalye
	Rect2(545, 478, 65, 130),     # hol sobasi
	Rect2(618, 548, 40, 35),      # tabure
	Rect2(545, 612, 100, 70),     # odun yigini
	Rect2(968, 638, 95, 45),      # sandiklar
	Rect2(1075, 645, 28, 35),     # semaver
	Rect2(1362, 628, 95, 55),     # mumlu masa
	Rect2(1326, 495, 72, 90),     # kitaplik (hol)
	Rect2(1268, 495, 55, 82),     # silah rafi
	Rect2(1066, 552, 85, 36),     # ayakkabilik
	Rect2(1410, 540, 92, 48),     # sandik
	Rect2(1562, 545, 38, 48),     # yay standi
	Rect2(1605, 540, 42, 48),     # koltuk
	Rect2(1708, 525, 75, 58),     # masa
	Rect2(1793, 530, 35, 50),     # kucuk masa
	Rect2(1833, 535, 45, 48),     # kucuk masa 2
	Rect2(1962, 525, 105, 68),    # cuvallar
	Rect2(2035, 565, 45, 62),     # sandik
	Rect2(1568, 632, 85, 116),    # mutfak ocagi (alt kenar: ocagin gorunen tabani, y=748)
	Rect2(1655, 618, 112, 128),   # mutfak rafi
	Rect2(1812, 626, 85, 56),     # variller
	Rect2(1908, 626, 50, 56),     # varil
	Rect2(1962, 628, 110, 55),    # sandiklar
	Rect2(1103, 658, 40, 62),     # antre sandalyesi
	Rect2(1288, 660, 34, 110),    # antre sandalyesi 2
	Rect2(1098, 735, 42, 42),     # sepet
	Rect2(660, 850, 108, 57),     # kuvet
	Rect2(660, 775, 40, 62),      # surahili masa
	Rect2(822, 698, 36, 64),      # klozet
	Rect2(898, 768, 30, 95),      # lavabo
	Rect2(822, 862, 30, 40),      # tabure
	Rect2(882, 872, 36, 36),      # kova
	Rect2(775, 852, 30, 45),      # surahi
	Rect2(1503, 765, 34, 145),    # mutfak tezgahi sol
	Rect2(1728, 765, 45, 145),    # mutfak tezgahi sag
	Rect2(1604, 803, 78, 62),     # mutfak masasi (gorunen masa genisligi)
	Rect2(1570, 803, 35, 62),     # mutfak sandalyesi
	Rect2(1638, 855, 30, 42),     # mutfak sandalyesi 2
	Rect2(1610, 778, 26, 28),     # mutfak sandalyesi 3
	Rect2(1828, 335, 65, 135),    # odunlar + komur
	Rect2(1826, 470, 66, 85),     # tas duvar (sol)
	Rect2(1990, 340, 45, 130),    # depo varilleri
	Rect2(1953, 340, 45, 55),     # depo cuvali
	Rect2(1963, 470, 110, 125),   # tas duvar (sag) + cuvallar
]

# Dis mekan engelleri (agaclar, buz golleri, odun yiginlari)
const OUT_OBST = [
	Rect2(10, 0, 190, 180),       # sol ust cam agaclari
	Rect2(20, 520, 110, 170),     # sol cam agaci
	Rect2(0, 900, 140, 193),      # sol alt cam agaclari
	Rect2(90, 1040, 100, 53),
	Rect2(2415, 0, 161, 170),     # sag ust
	Rect2(2455, 640, 121, 165),   # sag
	Rect2(2495, 925, 81, 168),    # sag alt
	Rect2(170, 175, 170, 150),    # buz golu sol ust
	Rect2(180, 760, 185, 170),    # buz golu sol alt
	Rect2(2260, 175, 140, 95),    # buz golu sag ust
	Rect2(2235, 825, 175, 125),   # buz golu sag alt
	Rect2(650, 965, 150, 80),     # odun yigini (alt)
	Rect2(805, 950, 95, 85),      # kuraklar
	Rect2(1500, 990, 50, 55),     # varil
	Rect2(1580, 975, 60, 50),     # cuval
	Rect2(1640, 985, 130, 50),    # sandiklar
	Rect2(1820, 750, 70, 60),     # odun yigini (sag)
	Rect2(1950, 760, 60, 45),     # sandik (sag)
]

# Evin icinde esya konabilecek noktalar (ayak konumu). Gecersizler otomatik elenir.
# Her nokta, esya ikonunun (~36x44 px, ayagin ustunde) duvara, kapi lentosuna ve mobilyaya
# TASMAYACAK sekilde haritada tek tek kontrol edildi (ana kapi onundeki esya dahil).
const ITEM_POINTS = [
	Vector2(730, 640), Vector2(800, 615), Vector2(850, 630), Vector2(920, 640),
	Vector2(970, 610), Vector2(1210, 650), Vector2(1310, 640), Vector2(1540, 640),
	Vector2(1920, 600), Vector2(700, 440), Vector2(790, 450), Vector2(1130, 370),
	Vector2(1200, 410), Vector2(1280, 410), Vector2(1370, 380), Vector2(1340, 440),
	Vector2(1930, 520), Vector2(750, 820), Vector2(840, 840), Vector2(1215, 718),
	Vector2(1545, 735), Vector2(1700, 792),
]


static func _in_walk(p: Vector2) -> bool:
	for i in range(WALK.size()):
		var r: Rect2 = WALK[i]
		if r.has_point(p):
			return true
	return false


static func _outside_ok(p: Vector2) -> bool:
	if p.x < 4.0 or p.y < 4.0 or p.x > MAP_SIZE.x - 4.0 or p.y > MAP_SIZE.y - 4.0:
		return false
	for i in range(HOUSE.size()):
		var h: Rect2 = HOUSE[i]
		if h.has_point(p):
			return false
	for i in range(OUT_OBST.size()):
		var o: Rect2 = OUT_OBST[i]
		if o.has_point(p):
			return false
	return true


# Nokta evin disinda mi? (ic mekan sayilmayan ve duvar olmayan alan)
static func is_outside(p: Vector2) -> bool:
	return (not _in_walk(p)) and _outside_ok(p)


# feet = karakterin ayak kutusu (dunya koordinati). gate_closed: ana kapi kilitli mi?
static func is_free(feet: Rect2, gate_closed: bool = false) -> bool:
	for ix in range(3):
		for iy in range(3):
			var p := feet.position + Vector2(feet.size.x * 0.5 * ix, feet.size.y * 0.5 * iy)
			if not (_in_walk(p) or _outside_ok(p)):
				return false
	for i in range(OBST.size()):
		var o: Rect2 = OBST[i]
		if o.intersects(feet):
			return false
	if gate_closed and DOOR_GATE.intersects(feet):
		return false
	return true


static func feet_rect(pos: Vector2) -> Rect2:
	return Rect2(pos.x - FEET_W * 0.5, pos.y - FEET_H, FEET_W, FEET_H)
