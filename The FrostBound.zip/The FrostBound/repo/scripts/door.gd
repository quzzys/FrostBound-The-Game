class_name Door
extends Node2D
# Evin kapilari: yaklasinca acilir (yaprak yana donup daralir), uzaklasinca kapanir.
# Kapidan gecerken pervaz + lento (kapinin ustundeki kiris) haritadan kesilip karakterin USTUNE cizilir,
# boylece karakter kapinin ALTINDAN geciyormis gibi gorunur.

var rect: Rect2 = Rect2()
var open_t: float = 0.0
var target: float = 0.0
var locked: bool = false
var hinge_left: bool = true
var opening_col: Color = Color(0.06, 0.04, 0.03)
var leaf_col: Color = Color(0.35, 0.22, 0.12)
var jamb_l: Sprite2D
var jamb_r: Sprite2D
var jamb_a: float = 0.0
var lintel: Sprite2D
var lintel_a: float = 0.0
var is_front: bool = false
var was_open: bool = false
var quiet: bool = false


func setup(map_tex: Texture2D, r: Rect2, hinge_on_left: bool = true, opening: Color = Color(0.06, 0.04, 0.03), front: bool = false) -> void:
	rect = r
	is_front = front
	hinge_left = hinge_on_left
	opening_col = opening
	# yaprak rengini haritadan ortala
	var img: Image = map_tex.get_image()
	if img != null and img.is_compressed():
		img.decompress()
	var sum := Vector3.ZERO
	var cnt := 0
	var x0 := int(r.position.x + r.size.x * 0.25)
	var x1 := int(r.position.x + r.size.x * 0.75)
	var y0 := int(r.position.y + r.size.y * 0.2)
	var y1 := int(r.position.y + r.size.y * 0.8)
	if img != null:
		for yy in range(y0, y1, 3):
			for xx in range(x0, x1, 3):
				var c := img.get_pixel(xx, yy)
				sum += Vector3(c.r, c.g, c.b)
				cnt += 1
	if cnt > 0:
		sum /= float(cnt)
		leaf_col = Color(sum.x, sum.y, sum.z).lightened(0.12)
	# pervazlar + lento: kapi cercevesindeki harita kesitleri (karakterin ustunde)
	var lin_r: Rect2
	var jl_r: Rect2
	var jr_r: Rect2
	if is_front:
		# ana kapi: karli kiris + iki ahsap direk (haritadan olculdu)
		lin_r = Rect2(r.position.x - 24.0, r.position.y - 31.0, r.size.x + 48.0, 32.0)
		jl_r = Rect2(r.position.x - 24.0, r.position.y + 1.0, 18.0, 94.0)
		jr_r = Rect2(r.end.x + 6.0, r.position.y + 1.0, 18.0, 94.0)
	else:
		lin_r = Rect2(r.position.x - 14.0, r.position.y - 20.0, r.size.x + 16.0, 22.0)
		jl_r = Rect2(r.position.x - 14.0, r.position.y - 20.0, 14.0, r.size.y + 20.0)
		jr_r = Rect2(r.end.x - 6.0, r.position.y - 20.0, 14.0, r.size.y + 20.0)
	jamb_l = _make_jamb(map_tex, jl_r)
	jamb_r = _make_jamb(map_tex, jr_r)
	lintel = _make_jamb(map_tex, lin_r)


func _make_jamb(tex: Texture2D, region: Rect2) -> Sprite2D:
	var at := AtlasTexture.new()
	at.atlas = tex
	at.region = region
	var s := Sprite2D.new()
	s.texture = at
	s.centered = false
	s.position = region.position
	s.z_index = 5
	s.modulate.a = 0.0
	add_child(s)
	return s


# actors: dunya konumu (ayak) listesi: oyuncu + takipciler
func tick(delta: float, actors: Array) -> void:
	var near := false
	var in_frame := false
	var passing := false
	var zone := rect.grow_individual(12.0, 46.0, 12.0, 52.0)
	var frame := Rect2(rect.position.x - 8.0, rect.position.y + 4.0, rect.size.x + 16.0, rect.size.y + 14.0)
	# lento bolgesi: ayak kapinin gecis alaninda iken (kafa/govde kirisin altinda kalir)
	var pass_zone: Rect2
	if is_front:
		pass_zone = Rect2(rect.position.x - 8.0, rect.position.y, rect.size.x + 16.0, rect.size.y + 8.0)
	else:
		pass_zone = Rect2(rect.position.x - 6.0, rect.position.y - 6.0, rect.size.x + 12.0, rect.size.y + 2.0)
	for p in actors:
		var pos: Vector2 = p
		if zone.has_point(pos):
			near = true
		if frame.has_point(pos):
			in_frame = true
		if pass_zone.has_point(pos):
			passing = true
	target = 1.0 if (near and not locked) else 0.0
	var prev := open_t
	open_t = move_toward(open_t, target, delta * (4.0 if target > open_t else 3.0))
	if prev <= 0.001 and open_t > 0.001 and not quiet:
		Sfx.play("door_o", -7.0, randf_range(0.92, 1.08))
	if prev > 0.001 and open_t <= 0.001 and not quiet:
		Sfx.play("door_c", -9.0, randf_range(0.92, 1.08))
	var is_open := open_t > 0.05
	jamb_a = move_toward(jamb_a, 1.0 if (in_frame and is_open) else 0.0, delta * 8.0)
	lintel_a = move_toward(lintel_a, 1.0 if (passing and is_open) else 0.0, delta * 10.0)
	jamb_l.modulate.a = jamb_a
	jamb_r.modulate.a = jamb_a
	lintel.modulate.a = lintel_a
	if open_t != prev or open_t > 0.0:
		queue_redraw()


func _draw() -> void:
	if open_t <= 0.001:
		return
	var r := rect.grow(-3.0)
	# aralik (icerisi)
	draw_rect(r, Color(opening_col.r, opening_col.g, opening_col.b, minf(1.0, open_t * 2.0)), true)
	draw_rect(Rect2(r.position.x, r.position.y, r.size.x, 5.0), Color(0, 0, 0, 0.45 * open_t), true)
	# yaprak: mentese tarafinda daralan panel
	var k := 1.0 - open_t * 0.86
	var w := r.size.x * k
	var lx := r.position.x if hinge_left else r.end.x - w
	var lr := Rect2(lx, r.position.y, w, r.size.y)
	draw_rect(lr, leaf_col, true)
	draw_rect(lr, leaf_col.darkened(0.45), false, 2.0)
	for i in range(1, 4):
		var yy := lr.position.y + lr.size.y * float(i) / 4.0
		draw_line(Vector2(lr.position.x + 2.0, yy), Vector2(lr.end.x - 2.0, yy), leaf_col.darkened(0.3), 1.0)
	# kapi kolu
	var hx := (lr.end.x - 5.0) if hinge_left else (lr.position.x + 5.0)
	draw_circle(Vector2(hx, lr.position.y + lr.size.y * 0.55), 2.2, Color(0.85, 0.7, 0.3))
