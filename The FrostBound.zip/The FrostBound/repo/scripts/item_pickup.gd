class_name ItemPickup
extends Node2D
# Evin icindeki toplanabilir hayatta kalma esyasi. Parlar, hafifce sallanir, pirilti saçar.

var def: Dictionary = {}
var tex: Texture2D
var collected: bool = false
var t: float = 0.0
var phase: float = 0.0
var icon: Sprite2D
var halo: Sprite2D
var sparkles: CPUParticles2D


func setup(item_def: Dictionary, texture: Texture2D) -> void:
	def = item_def
	tex = texture
	phase = randf() * TAU


func _ready() -> void:
	halo = Sprite2D.new()
	halo.texture = Fx.glow_tex()
	halo.material = Fx.additive()
	halo.position = Vector2(0, -22)
	halo.scale = Vector2(0.75, 0.75)
	halo.modulate = Color(1.0, 0.85, 0.35, 0.55)
	add_child(halo)

	icon = Sprite2D.new()
	icon.texture = tex
	icon.position = Vector2(0, -26)
	add_child(icon)

	sparkles = CPUParticles2D.new()
	sparkles.amount = 6
	sparkles.lifetime = 1.2
	sparkles.direction = Vector2(0, -1)
	sparkles.spread = 60.0
	sparkles.gravity = Vector2(0, -10)
	sparkles.initial_velocity_min = 8.0
	sparkles.initial_velocity_max = 22.0
	sparkles.scale_amount_min = 0.03
	sparkles.scale_amount_max = 0.07
	sparkles.texture = Fx.glow_tex()
	sparkles.material = Fx.additive()
	sparkles.emission_shape = CPUParticles2D.EMISSION_SHAPE_SPHERE
	sparkles.emission_sphere_radius = 16.0
	sparkles.position = Vector2(0, -22)
	var ramp := Gradient.new()
	ramp.set_color(0, Color(1.0, 0.95, 0.6, 1.0))
	ramp.set_color(1, Color(1.0, 0.9, 0.4, 0.0))
	sparkles.color_ramp = ramp
	add_child(sparkles)


func _process(delta: float) -> void:
	if collected:
		return
	t += delta
	icon.position.y = -26.0 + sin(t * 3.0 + phase) * 4.0
	icon.rotation = sin(t * 2.0 + phase) * 0.08
	var s := 0.7 + 0.12 * sin(t * 4.0 + phase)
	halo.scale = Vector2(s, s)
	halo.position.y = icon.position.y + 4.0
	queue_redraw()


func _draw() -> void:
	# zemin golgesi
	draw_set_transform(Vector2(0, 0), 0.0, Vector2(1.0, 0.35))
	draw_circle(Vector2.ZERO, 16.0, Color(0, 0, 0, 0.35))
	draw_set_transform(Vector2.ZERO, 0.0, Vector2.ONE)
