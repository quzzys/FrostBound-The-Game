class_name Dialogues
extends RefCounted
# Kazazedelerin kisa hikayeleri. Metinleri buradan kolayca degistirebilirsin.
# Satir bicimi: ["n", "..."] = kazazede konusur, ["p", "..."] = oyuncu (SEN) konusur.
# pitch: konusma sesi tonu, color: isim rengi

const PLAYER_NAME := "SEN"

const DATA = {
	"barbaros": {
		"name": "BARBAROS",
		"role": "Yaşlı balıkçı",
		"pitch": 0.72,
		"color": Color(0.95, 0.75, 0.4),
		"lines": [
			["n", "Elli yıl denizdeydim, bu soğuk beni yenemez... dizlerim hariç."],
			["p", "Kalk usta, sığınak yakın. Beni takip et!"],
			["n", "Pusulam seni gösteriyor evlat. Önden sen!"],
		],
	},
	"leyla": {
		"name": "LEYLA",
		"role": "Sokak müzisyeni",
		"pitch": 1.28,
		"color": Color(1.0, 0.55, 0.7),
		"lines": [
			["n", "Gitarım donarsa teller kopar... onu bırakıp gidemem!"],
			["p", "Gitarını da al, sığınakta çalarsın. Hadi!"],
			["n", "Sana ilk şarkıyı yazacağım. Söz!"],
		],
	},
	"selahattin": {
		"name": "SELAHATTİN",
		"role": "Koruma görevlisi",
		"pitch": 0.88,
		"color": Color(0.7, 0.8, 1.0),
		"lines": [
			["n", "Koruduğum adam beni bırakıp kaçtı. Takım elbiseyle kardayım."],
			["p", "Bu sefer kendini koru. Sığınağa geliyorsun!"],
			["n", "Anlaşıldı. Güvenlik işi bende."],
		],
	},
	"yusuf": {
		"name": "YUSUF",
		"role": "Tamirci",
		"pitch": 0.82,
		"color": Color(0.85, 0.65, 0.4),
		"lines": [
			["n", "Jeneratörü son kez çalıştırmaya uğraşıyordum. O da dondu."],
			["p", "Sığınağın havalandırması senin işin olacak."],
			["n", "Hesabım doğruysa vakit daralıyor. Koşalım!"],
		],
	},
	"zeynep": {
		"name": "ZEYNEP",
		"role": "Uzay Ajansı stajyeri",
		"pitch": 1.12,
		"color": Color(0.4, 0.95, 0.9),
		"lines": [
			["n", "Yörünge sapmasını ilk ben fark ettim ama kimse inanmadı!"],
			["p", "Şimdi herkes inandı. Gel, hayatta kalalım!"],
			["n", "Sığınakta sana hesabı baştan anlatacağım. Hadi!"],
		],
	},
}

const ORDER := ["leyla", "barbaros", "yusuf", "selahattin", "zeynep"]
