class_name Survivor
extends Node2D
# Disarida mahsur kalmis kazazede. Yardim ister (ses + halka + isik huzmesi),
# kurtarilinca oyuncuyu takip eder, sigınaga atlar.

var id: String = ""
var tex: Array = []
var sprite: Sprite2D
var halo: Sprite2D
var beacon: Sprite2D
var breath: CPUParticles2D
var voice: AudioStreamPlayer2D

var calling: bool = false
var rescued: bool = false
var frozen: bool = false
var cold: float = 0.0
var t: float = 0.0
var anim_t: float = 0.0
var call_timer: float = 1.0
var ring_timer: float = 0.5
var moving: bool = false
var last_pos: Vector2 = Vector2.ZERO
var bubble_t: float = 0.0
var pitch: float = 1.0


func setup(survivor_id: String) -> void:
	id = survivor_id
	for i in range(3):
		tex.append(load("res://assets/npc/%s_%d.png" % [id, i]))
	pitch = float(Dialogues.DATA[id]["pitch"])


func _ready() -> void:
	# yardim isigi (uzaktan gorunsun)
	beacon = Sprite2D.new()
	beacon.texture = Fx.glow_tex()
	beacon.material = Fx.additive()
	beacon.scale = Vector2(0.9, 5.0)
	beacon.position = Vector2(0, -150)
	beacon.modulate = Color(1.0, 0.55, 0.2, 0.0)
	add_child(beacon)
	halo = Sprite2D.new()
	halo.texture = Fx.glow_tex()
	halo.material = Fx.additive()
	halo.scale = Vector2(1.6, 1.3)
	halo.position = Vector2(0, -34)
	halo.modulate = Color(1.0, 0.7, 0.3, 0.0)
	add_child(halo)

	sprite = Sprite2D.new()
	sprite.texture = tex[0]
	sprite.offset = Vector2(0, -48)
	add_child(sprite)

	breath = CPUParticles2D.new()
	breath.amount = 8
	breath.lifetime = 1.1
	breath.direction = Vector2(0, -1)
	breath.spread = 35.0
	breath.gravity = Vector2(0, -22)
	breath.initial_velocity_min = 8.0
	breath.initial_velocity_max = 22.0
	breath.scale_amount_min = 0.05
	breath.scale_amount_max = 0.13
	breath.texture = Fx.glow_tex()
	var ramp := Gradient.new()
	ramp.set_color(0, Color(0.9, 0.96, 1.0, 0.0))
	ramp.add_point(0.25, Color(0.9, 0.96, 1.0, 0.55))
	ramp.set_color(ramp.get_point_count() - 1, Color(0.9, 0.96, 1.0, 0.0))
	breath.color_ramp = ramp
	breath.position = Vector2(0, -62)
	breath.emitting = true
	add_child(breath)

	voice = AudioStreamPlayer2D.new()
	voice.stream = Sfx.stream("cry")
	voice.volume_db = 2.0
	voice.max_distance = 1500.0
	voice.attenuation = 1.3
	voice.pitch_scale = pitch
	add_child(voice)
	last_pos = position
	call_timer = randf_range(0.3, 1.6)


func _draw() -> void:
	draw_set_transform(Vector2(0, -2), 0.0, Vector2(1.0, 0.38))
	draw_circle(Vector2.ZERO, 22.0, Color(0, 0, 0, 0.38))
	draw_set_transform(Vector2.ZERO, 0.0, Vector2.ONE)
	if calling and not rescued:
		# bas ustunde yanip sonen unlem balonu
		var f := ThemeDB.fallback_font
		var by := -118.0 + sin(t * 8.0) * 3.0
		draw_circle(Vector2(0, by), 13.0, Color(0.1, 0.05, 0.02, 0.85))
		draw_arc(Vector2(0, by), 13.0, 0.0, TAU, 20, Color(1.0, 0.7, 0.2, 1.0), 2.0)
		draw_string(f, Vector2(-5, by + 8.0), "!", HORIZONTAL_ALIGNMENT_CENTER, 10.0, 22, Color(1.0, 0.85, 0.3))


func start_calling() -> void:
	calling = true


func rescue() -> void:
	rescued = true
	calling = false
	var tw := create_tween()
	tw.tween_property(halo, "modulate:a", 0.0, 0.4)
	create_tween().tween_property(beacon, "modulate:a", 0.0, 0.4)
	voice.stop()
	queue_redraw()


func freeze() -> void:
	frozen = true
	breath.emitting = true
	sprite.texture = tex[0]
	create_tween().tween_property(sprite, "modulate", Color(0.55, 0.8, 1.35), 1.6)


func _process(delta: float) -> void:
	t += delta
	if frozen:
		sprite.offset = Vector2(randf_range(-1.0, 1.0), -48.0 + randf_range(-0.5, 0.5))
		return

	if not rescued:
		# titreyen, soguktan morarmis kazazede
		sprite.offset = Vector2(randf_range(-1.0, 1.0) * (0.6 + cold), -48.0 + sin(t * 3.0) * 1.2)
		sprite.modulate = Color(1, 1, 1).lerp(Color(0.72, 0.85, 1.25), cold * 0.6)
		sprite.texture = tex[0]
		if calling:
			var pulse := 0.5 + 0.5 * sin(t * 6.0)
			halo.modulate = Color(1.0, 0.65, 0.25, 0.22 + 0.2 * pulse)
			beacon.modulate = Color(1.0, 0.55, 0.2, 0.10 + 0.07 * pulse)
			queue_redraw()
			call_timer -= delta
			if call_timer <= 0.0:
				call_timer = randf_range(3.2, 4.4)
				voice.play()
				Fx.ring(get_parent(), position + Vector2(0, -34), Color(1.0, 0.7, 0.3, 0.9), 140.0, 1.2, 4.0)
			ring_timer -= delta
			if ring_timer <= 0.0:
				ring_timer = 1.1
				Fx.ring(get_parent(), position + Vector2(0, -34), Color(1.0, 0.55, 0.2, 0.55), 70.0, 0.8, 2.0)
	else:
		# takipci animasyonu
		var moved := (position - last_pos).length()
		moving = moved > 0.4
		last_pos = position
		if moving:
			anim_t += delta * 9.0
			var fr := 1 + (int(anim_t) % 2)
			sprite.texture = tex[fr]
			sprite.offset = Vector2(0, -48.0 - absf(sin(anim_t * 3.14159)) * 3.0)
		else:
			sprite.texture = tex[0]
			sprite.offset = Vector2(0, -48)
		sprite.modulate = Color(1, 1, 1).lerp(Color(0.8, 0.9, 1.15), cold * 0.45)


# Takip: hedefe dogru yumusak yurur
func follow(delta: float, target: Vector2) -> void:
	var d := target - position
	var dist := d.length()
	if dist > 3.0:
		var spd: float = minf(dist * 6.0, 440.0)
		position += d / dist * spd * delta
		if absf(d.x) > 1.5:
			sprite.flip_h = d.x < 0.0


func set_cold(c: float) -> void:
	cold = c
	breath.emitting = true
