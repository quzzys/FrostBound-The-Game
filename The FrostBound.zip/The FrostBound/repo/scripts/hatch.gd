class_name Hatch
extends Node2D
# Sag ustteki depo odasindaki SIGINAK GIRISI (assets/hatch_*.png piksel sanati).
# Kilitliyken kirmizi lamba yanar; tum kazazedeler toplaninca kapaklar acilir, yesil isik ve sicak hava cikar.

var open_t: float = 0.0
var unlocked: bool = false
var t: float = 0.0
var glow: Sprite2D
var beam: Sprite2D
var closed_spr: Sprite2D
var open_spr: Sprite2D
var lamps: Array = []
var warm: CPUParticles2D
var label_txt: String = "SIĞINAK"


func _ready() -> void:
	glow = Sprite2D.new()
	glow.texture = Fx.glow_tex()
	glow.material = Fx.additive()
	glow.scale = Vector2(2.2, 1.5)
	glow.modulate = Color(1.0, 0.15, 0.1, 0.3)
	add_child(glow)

	closed_spr = Sprite2D.new()
	closed_spr.texture = load("res://assets/hatch_closed.png")
	add_child(closed_spr)
	open_spr = Sprite2D.new()
	open_spr.texture = load("res://assets/hatch_open.png")
	open_spr.modulate.a = 0.0
	add_child(open_spr)

	# kose lambalari (renkli isik)
	for lx in [-39.0, 39.0]:
		var l := Sprite2D.new()
		l.texture = Fx.glow_tex()
		l.material = Fx.additive()
		l.position = Vector2(lx, 23)
		l.scale = Vector2(0.42, 0.42)
		l.modulate = Color(1, 0.1, 0.1, 0.8)
		add_child(l)
		lamps.append(l)

	beam = Sprite2D.new()
	beam.texture = Fx.glow_tex()
	beam.material = Fx.additive()
	beam.scale = Vector2(0.9, 2.4)
	beam.position = Vector2(0, -26)
	beam.modulate = Color(0.4, 1.0, 0.6, 0.0)
	add_child(beam)

	# sicak hava / kivilcim (acilinca)
	warm = CPUParticles2D.new()
	warm.amount = 18
	warm.lifetime = 1.6
	warm.direction = Vector2(0, -1)
	warm.spread = 25.0
	warm.gravity = Vector2(0, -28)
	warm.initial_velocity_min = 16.0
	warm.initial_velocity_max = 44.0
	warm.scale_amount_min = 0.03
	warm.scale_amount_max = 0.09
	warm.texture = Fx.glow_tex()
	warm.material = Fx.additive()
	warm.emission_shape = CPUParticles2D.EMISSION_SHAPE_RECTANGLE
	warm.emission_rect_extents = Vector2(26, 6)
	var ramp := Gradient.new()
	ramp.set_color(0, Color(0.8, 1.0, 0.7, 0.9))
	ramp.set_color(1, Color(1.0, 0.9, 0.4, 0.0))
	warm.color_ramp = ramp
	warm.position = Vector2(0, 8)
	warm.emitting = false
	add_child(warm)


func unlock() -> void:
	unlocked = true
	warm.emitting = true
	var tw := create_tween()
	tw.tween_property(self, "open_t", 1.0, 1.3).set_trans(Tween.TRANS_QUART).set_ease(Tween.EASE_OUT)
	Fx.burst(get_parent(), position + Vector2(0, -6), Color(0.5, 1.0, 0.65), 40, 220.0, 0.9, 0.16)
	Fx.ring(get_parent(), position, Color(0.5, 1.0, 0.65, 0.9), 150.0, 1.1, 4.0)


func close_up() -> void:
	warm.emitting = false
	var tw := create_tween()
	tw.tween_property(self, "open_t", 0.0, 0.5).set_trans(Tween.TRANS_QUAD).set_ease(Tween.EASE_IN)


func _process(delta: float) -> void:
	t += delta
	var pulse := 0.5 + 0.5 * sin(t * (3.0 if not unlocked else 5.0))
	open_spr.modulate.a = open_t
	closed_spr.modulate.a = 1.0 - open_t * 0.9
	if unlocked:
		glow.modulate = Color(0.2, 1.0, 0.5, 0.22 + 0.18 * pulse)
		beam.modulate = Color(0.4, 1.0, 0.6, 0.35 * open_t * (0.7 + 0.3 * pulse))
		for l in lamps:
			(l as Sprite2D).modulate = Color(0.2, 1.0, 0.45, 0.8)
	else:
		glow.modulate = Color(1.0, 0.15, 0.1, 0.16 + 0.24 * pulse)
		beam.modulate = Color(0.4, 1.0, 0.6, 0.0)
		for l in lamps:
			(l as Sprite2D).modulate = Color(1.0, 0.1 + 0.2 * pulse, 0.1, 0.5 + 0.4 * pulse)
	queue_redraw()


func _draw() -> void:
	var font := ThemeDB.fallback_font
	var txt := "SIĞINAK (KİLİTLİ)" if not unlocked else "SIĞINAK  ▼"
	var col := Color(1.0, 0.35, 0.3) if not unlocked else Color(0.5, 1.0, 0.6)
	var bob := sin(t * 5.0) * 3.0 if unlocked else 0.0
	draw_string_outline(font, Vector2(-110, -42 + bob), txt, HORIZONTAL_ALIGNMENT_CENTER, 220.0, 15, 6, Color(0, 0, 0, 0.9))
	draw_string(font, Vector2(-110, -42 + bob), txt, HORIZONTAL_ALIGNMENT_CENTER, 220.0, 15, col)
