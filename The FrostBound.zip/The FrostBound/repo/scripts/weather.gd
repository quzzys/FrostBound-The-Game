class_name Weather
extends CanvasLayer
# Ekran uzayinda kar firtinasi: kar taneleri, ince kar, ruzgar cizgileri + ic mekan toz yagmuru.
# Disaridayken gorunur ve zamanla siddetlenir; ruzgar patlamalari (gust) ekler.

var root: Control
var heavy: CPUParticles2D
var fine: CPUParticles2D
var streaks: CPUParticles2D
var dust: CPUParticles2D
var outside_k: float = 0.0
var target_outside: float = 0.0
var progress: float = 0.0
var gust_k: float = 0.0
var gust_cd: float = 7.0
var t: float = 0.0
signal gust_started


func _ready() -> void:
	layer = 4
	root = Control.new()
	root.set_anchors_preset(Control.PRESET_FULL_RECT)
	root.mouse_filter = Control.MOUSE_FILTER_IGNORE
	root.modulate = Color(1, 1, 1, 0)
	add_child(root)

	heavy = _make_flakes(Fx.flake_tex(), 150, 3.4, Vector2(-0.35, 1.0), 90.0, 190.0, 0.5, 1.5, 0.95)
	fine = _make_flakes(Fx.dot_tex(), 220, 2.6, Vector2(-0.5, 1.0), 120.0, 240.0, 0.18, 0.42, 0.8)
	streaks = CPUParticles2D.new()
	streaks.amount = 22
	streaks.lifetime = 1.0
	streaks.emission_shape = CPUParticles2D.EMISSION_SHAPE_RECTANGLE
	streaks.emission_rect_extents = Vector2(40, 380)
	streaks.position = Vector2(1330, 360)
	streaks.direction = Vector2(-1, 0.12)
	streaks.spread = 4.0
	streaks.gravity = Vector2.ZERO
	streaks.initial_velocity_min = 1100.0
	streaks.initial_velocity_max = 1700.0
	streaks.scale_amount_min = 1.2
	streaks.scale_amount_max = 3.2
	streaks.texture = Fx.streak_tex()
	var sr := Gradient.new()
	sr.set_color(0, Color(0.9, 0.96, 1.0, 0.0))
	sr.add_point(0.2, Color(0.9, 0.96, 1.0, 0.45))
	sr.set_color(sr.get_point_count() - 1, Color(0.9, 0.96, 1.0, 0.0))
	streaks.color_ramp = sr
	streaks.emitting = false
	root.add_child(streaks)

	dust = CPUParticles2D.new()
	dust.one_shot = true
	dust.amount = 70
	dust.lifetime = 2.4
	dust.explosiveness = 0.35
	dust.emission_shape = CPUParticles2D.EMISSION_SHAPE_RECTANGLE
	dust.emission_rect_extents = Vector2(680, 6)
	dust.position = Vector2(640, -8)
	dust.direction = Vector2(0, 1)
	dust.spread = 14.0
	dust.gravity = Vector2(0, 260)
	dust.initial_velocity_min = 40.0
	dust.initial_velocity_max = 150.0
	dust.scale_amount_min = 0.25
	dust.scale_amount_max = 0.7
	dust.texture = Fx.dot_tex()
	var dr := Gradient.new()
	dr.set_color(0, Color(0.55, 0.45, 0.35, 0.0))
	dr.add_point(0.15, Color(0.6, 0.5, 0.4, 0.8))
	dr.set_color(dr.get_point_count() - 1, Color(0.45, 0.38, 0.3, 0.0))
	dust.color_ramp = dr
	dust.emitting = false
	root.add_child(dust)


func _make_flakes(tx: Texture2D, amt: int, life: float, dir: Vector2, v0: float, v1: float, s0: float, s1: float, alpha: float) -> CPUParticles2D:
	var p := CPUParticles2D.new()
	p.amount = amt
	p.lifetime = life
	p.preprocess = life
	p.emission_shape = CPUParticles2D.EMISSION_SHAPE_RECTANGLE
	p.emission_rect_extents = Vector2(820, 400)
	p.position = Vector2(640, 360)
	p.direction = dir
	p.spread = 22.0
	p.gravity = Vector2(-60, 40)
	p.initial_velocity_min = v0
	p.initial_velocity_max = v1
	p.angular_velocity_min = -90.0
	p.angular_velocity_max = 90.0
	p.scale_amount_min = s0
	p.scale_amount_max = s1
	p.texture = tx
	var r := Gradient.new()
	r.set_color(0, Color(1, 1, 1, 0.0))
	r.add_point(0.15, Color(0.95, 0.98, 1.0, alpha))
	r.add_point(0.85, Color(0.95, 0.98, 1.0, alpha))
	r.set_color(r.get_point_count() - 1, Color(1, 1, 1, 0.0))
	p.color_ramp = r
	p.emitting = true
	root.add_child(p)
	return p


func set_outside(o: bool) -> void:
	target_outside = 1.0 if o else 0.0


func set_progress(p: float) -> void:
	progress = p


# disaridaki intensity (post shader icin)
func intensity() -> float:
	return outside_k * (0.35 + 0.65 * progress)


func quake() -> void:
	dust.restart()
	dust.emitting = true


func _process(delta: float) -> void:
	t += delta
	outside_k = move_toward(outside_k, target_outside, delta * 1.6)
	root.modulate.a = outside_k
	var on := outside_k > 0.02
	streaks.emitting = on and progress > 0.12
	# ruzgar patlamalari
	gust_cd -= delta
	if gust_cd <= 0.0 and on:
		gust_cd = randf_range(5.0, 9.0) - progress * 2.5
		gust_started.emit()
		var tw := create_tween()
		tw.tween_property(self, "gust_k", 1.0, 0.7)
		tw.tween_interval(0.8)
		tw.tween_property(self, "gust_k", 0.0, 1.6)
	var wind := 55.0 + progress * 120.0 + gust_k * 330.0
	heavy.gravity = Vector2(-wind, 40.0)
	fine.gravity = Vector2(-wind * 1.2, 50.0)
	var sp := 0.8 + progress * 0.7 + gust_k * 0.6
	heavy.speed_scale = sp
	fine.speed_scale = sp
	streaks.speed_scale = 0.8 + gust_k * 0.9
