class_name DialogueBox
extends Control
# Kurtarmadan once cikan kisa konusma kutusu: portre, isim, daktilo yazisi, konusma sesi.
# Bosluk / Enter: yazıyı tamamla / sonraki satir. Kendiliginden de ilerler.

signal finished

const CPS := 52.0        # saniyede harf
const HOLD := 1.0        # satir bittikten sonra bekleme

var active: bool = false
var lines: Array = []
var idx: int = 0
var typed: float = 0.0
var hold_t: float = 0.0
var cur_len: int = 0
var last_n: int = 0
var data: Dictionary = {}
var npc_tex: Texture2D
var player_tex: Texture2D

var panel: Panel
var portrait: TextureRect
var name_label: Label
var role_label: Label
var text_label: Label
var hint: Label
var slide_t: float = 0.0


func _ready() -> void:
	set_anchors_preset(Control.PRESET_FULL_RECT)
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	visible = false
	panel = Panel.new()
	panel.size = Vector2(1120, 178)
	panel.position = Vector2(80, 520)
	var sb := StyleBoxFlat.new()
	sb.bg_color = Color(0.03, 0.05, 0.1, 0.92)
	sb.border_color = Color(0.55, 0.8, 1.0, 0.9)
	sb.set_border_width_all(3)
	sb.set_corner_radius_all(12)
	panel.add_theme_stylebox_override("panel", sb)
	add_child(panel)

	var frame := Panel.new()
	frame.position = Vector2(16, 16)
	frame.size = Vector2(130, 146)
	var fsb := StyleBoxFlat.new()
	fsb.bg_color = Color(0.1, 0.16, 0.25, 1.0)
	fsb.border_color = Color(0.4, 0.65, 0.95, 1.0)
	fsb.set_border_width_all(2)
	fsb.set_corner_radius_all(8)
	frame.add_theme_stylebox_override("panel", fsb)
	panel.add_child(frame)
	portrait = TextureRect.new()
	portrait.position = Vector2(2, 2)
	portrait.size = Vector2(126, 142)
	portrait.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	portrait.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
	portrait.texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
	frame.add_child(portrait)

	name_label = _lbl(26, Color.WHITE)
	name_label.position = Vector2(166, 12)
	panel.add_child(name_label)
	role_label = _lbl(16, Color(0.7, 0.8, 0.95))
	role_label.position = Vector2(170, 46)
	panel.add_child(role_label)
	text_label = _lbl(26, Color(0.95, 0.97, 1.0))
	text_label.position = Vector2(166, 76)
	text_label.size = Vector2(920, 80)
	text_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	panel.add_child(text_label)
	hint = _lbl(14, Color(1.0, 0.9, 0.5))
	hint.text = "BOŞLUK ▸"
	hint.position = Vector2(1010, 148)
	panel.add_child(hint)


func _lbl(size: int, col: Color) -> Label:
	var l := Label.new()
	l.add_theme_font_size_override("font_size", size)
	l.add_theme_color_override("font_color", col)
	l.add_theme_color_override("font_outline_color", Color(0, 0, 0, 0.9))
	l.add_theme_constant_override("outline_size", 5)
	l.mouse_filter = Control.MOUSE_FILTER_IGNORE
	return l


func start(id: String, ptex: Texture2D, ntex: Texture2D) -> void:
	data = Dialogues.DATA[id]
	lines = data["lines"]
	npc_tex = ntex
	player_tex = ptex
	idx = -1
	active = true
	visible = true
	slide_t = 0.0
	panel.position.y = 760.0
	_next_line()


func _next_line() -> void:
	idx += 1
	if idx >= lines.size():
		_end()
		return
	var ln: Array = lines[idx]
	var who: String = ln[0]
	var txt: String = ln[1]
	if who == "n":
		portrait.texture = npc_tex
		name_label.text = String(data["name"])
		name_label.add_theme_color_override("font_color", data["color"])
		role_label.text = String(data["role"])
	else:
		portrait.texture = player_tex
		name_label.text = Dialogues.PLAYER_NAME
		name_label.add_theme_color_override("font_color", Color(0.6, 1.0, 0.65))
		role_label.text = "Eski asker"
	text_label.text = txt
	text_label.visible_characters = 0
	cur_len = txt.length()
	typed = 0.0
	last_n = 0
	hold_t = 0.0


func _end() -> void:
	active = false
	visible = false
	finished.emit()


func advance() -> void:
	if not active:
		return
	if int(typed) < cur_len:
		typed = float(cur_len)
		text_label.visible_characters = cur_len
	else:
		_next_line()


func _process(delta: float) -> void:
	if not active:
		return
	# alttan kayarak gelsin
	slide_t = minf(1.0, slide_t + delta * 4.0)
	panel.position.y = lerpf(760.0, 520.0, 1.0 - pow(1.0 - slide_t, 3.0))
	if int(typed) < cur_len:
		typed += delta * CPS
		var n := mini(int(typed), cur_len)
		text_label.visible_characters = n
		if n != last_n:
			if n % 2 == 0:
				var pitch: float = float(data["pitch"]) if String(lines[idx][0]) == "n" else 1.0
				Sfx.play("blip", -12.0, pitch * randf_range(0.93, 1.08))
			last_n = n
		hint.modulate.a = 0.0
	else:
		hold_t += delta
		hint.modulate.a = 0.5 + 0.5 * sin(Time.get_ticks_msec() * 0.012)
		if hold_t >= HOLD:
			_next_line()
